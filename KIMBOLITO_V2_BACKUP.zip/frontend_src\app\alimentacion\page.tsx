"use client";

import {
  useEffect,
  useState,
} from "react";

import {
  Food,
  FeedingCalculation,
  FeedingRecord,
  getFoods,
  calculateFeeding,
  feedNow,
  testFeeding,
  openWhatsApp,
} from "@/lib/api";

export default function AlimentacionPage() {

  const [foods, setFoods] =
    useState<Food[]>([]);

  const [selectedFood, setSelectedFood] =
    useState<number | null>(null);

  const [grams, setGrams] =
    useState<number>(5);

  const [calculation, setCalculation] =
    useState<FeedingCalculation | null>(null);

  const [loading, setLoading] =
    useState(false);

  const [message, setMessage] =
    useState("");

  const [error, setError] =
    useState("");


  // ===================================================
  // CARGAR ALIMENTOS
  // ===================================================

  useEffect(() => {

    async function loadFoods() {

      try {

        const data =
          await getFoods();

        setFoods(data);

        if (data.length > 0) {
          setSelectedFood(data[0].id);
        }

      } catch (err) {

        setError(
          err instanceof Error
            ? err.message
            : "No se pudieron cargar los alimentos."
        );
      }
    }

    loadFoods();

  }, []);


  // ===================================================
  // CALCULAR
  // ===================================================

  async function handleCalculate() {

    if (!selectedFood) {
      setError("Seleccione un alimento.");
      return;
    }

    if (grams <= 0) {
      setError(
        "La cantidad debe ser mayor que 0 gramos."
      );
      return;
    }

    try {

      setError("");

      const result =
        await calculateFeeding(
          selectedFood,
          grams
        );

      setCalculation(result);

    } catch (err) {

      setError(
        err instanceof Error
          ? err.message
          : "No se pudo calcular."
      );
    }
  }


  // ===================================================
  // DAR COMIDA
  // ===================================================

  async function handleFeedNow() {

    if (!selectedFood) {
      setError("Seleccione un alimento.");
      return;
    }

    try {

      setLoading(true);
      setError("");
      setMessage("");

      const result =
        await feedNow(
          selectedFood,
          grams
        );

      setMessage(
        `Alimentación registrada. ${result.duration_seconds} segundos.`
      );
      sendManualWhatsApp(result);

      setCalculation({
        food_id: result.food_id,
        grams: result.grams,
        flow_rate:
          foods.find(
            food => food.id === result.food_id
          )?.flow_rate || 0,
        duration_seconds:
          result.duration_seconds,
      });

    } catch (err) {

      setError(
        err instanceof Error
          ? err.message
          : "No se pudo realizar la alimentación."
      );

    } finally {

      setLoading(false);
    }
  }


  // ===================================================
  // PRUEBA
  // ===================================================

  async function handleTest() {

    if (!selectedFood) {
      setError("Seleccione un alimento.");
      return;
    }

    try {

      setLoading(true);
      setError("");
      setMessage("");

      const result =
        await testFeeding(
          selectedFood,
          grams
        );

      setMessage(
        `Prueba registrada. ${result.duration_seconds} segundos.`
      );

    } catch (err) {

      setError(
        err instanceof Error
          ? err.message
          : "No se pudo realizar la prueba."
      );

    } finally {

      setLoading(false);
    }
  }


  // =====================================================
// WHATSAPP - ALIMENTACIÓN MANUAL
// =====================================================

function sendManualWhatsApp(result: FeedingRecord) {
  const food = foods.find(
    (item) => item.id === result.food_id
  );

  const now = new Date();

  const message = `
🐹KIMBOLITO

🍽️ ALIMENTACIÓN REALIZADA

Tipo: Alimentación manual
Alimento: ${food?.name ?? `Alimento #${result.food_id}`}
Cantidad estimada: ${result.grams} g
Tiempo de apertura: ${result.duration_seconds} segundos

📅 Fecha: ${now.toLocaleDateString("es-EC")}
🕐 Hora: ${now.toLocaleTimeString("es-EC")}

✅ Acción registrada correctamente.
`.trim();

  openWhatsApp(message);
}


// =====================================================
// WHATSAPP - PRUEBA
// =====================================================

function sendTestWhatsApp(result: FeedingRecord) {
  const food = foods.find(
    (item) => item.id === result.food_id
  );

  const now = new Date();

  const message = `
🐹 KIMBOLITO

🧪 PRUEBA DE ALIMENTACIÓN

Alimento: ${food?.name ?? `Alimento #${result.food_id}`}
Cantidad estimada: ${result.grams} g
Tiempo de apertura: ${result.duration_seconds} segundos

📅 Fecha: ${now.toLocaleDateString("es-EC")}
🕐 Hora: ${now.toLocaleTimeString("es-EC")}

✅ Prueba registrada correctamente.
`.trim();

  openWhatsApp(message);
}
  return (

    <main className="feeding-page">

      <div className="feeding-header">

        <div>

          <span className="eyebrow">
            ALIMENTACIÓN
          </span>
          

          <h1>
            Alimentación del hamster
          </h1>

          <p>
            Configura la cantidad y controla
            la alimentación desde un solo lugar.
          </p>

        </div>

      </div>


      <section className="feeding-layout">

        {/* ==========================================
            CONFIGURACIÓN
        ========================================== */}

        <div className="feeding-card">

          <h2>
            Dar alimento
          </h2>

          <div className="form-group">

            <label>
              Tipo de alimento
            </label>

            <select
              value={selectedFood ?? ""}
              onChange={(event) =>
                setSelectedFood(
                  Number(event.target.value)
                )
              }
            >

              {foods.length === 0 && (
                <option value="">
                  No hay alimentos
                </option>
              )}

              {foods.map((food) => (

                <option
                  key={food.id}
                  value={food.id}
                >
                  {food.name}
                </option>

              ))}

            </select>

          </div>


          <div className="form-group">

            <label>
              Cantidad
            </label>

            <div className="grams-input">

              <input
                type="number"
                min="0.1"
                step="0.1"
                value={grams}
                onChange={(event) =>
                  setGrams(
                    Number(event.target.value)
                  )
                }
              />

              <span>
                gramos
              </span>

            </div>

          </div>


          <button
            className="secondary-button"
            onClick={handleCalculate}
            disabled={loading}
          >
            Calcular tiempo
          </button>


          {calculation && (

            <div className="calculation-box">

              <span>
                Tiempo calculado
              </span>

              <strong>
                {calculation.duration_seconds}
                {" "}
                segundos
              </strong>

              <small>
                Aproximadamente{" "}
                {calculation.grams} g
              </small>

            </div>

          )}


          <div className="feeding-actions">

            <button
              className="primary-button"
              onClick={handleFeedNow}
              disabled={
                loading ||
                foods.length === 0
              }
            >
              {loading
                ? "Procesando..."
                : "🍽️ Dar comida ahora"}
            </button>


            <button
              className="test-button"
              onClick={handleTest}
              disabled={
                loading ||
                foods.length === 0
              }
            >
              🧪 Prueba
            </button>

          </div>


          {message && (

            <div className="success-message">
              ✓ {message}
            </div>

          )}


          {error && (

            <div className="error-message">
              {error}
            </div>

          )}

        </div>


        {/* ==========================================
            INFORMACIÓN
        ========================================== */}

        <div className="feeding-info">

          <div className="info-card">

            <span className="info-icon">
              🐹
            </span>

            <h3>
              Alimentación controlada
            </h3>

            <p>
              La aplicación calcula
              automáticamente el tiempo
              que debe permanecer abierta
              la compuerta según el tipo
              de alimento.
            </p>

          </div>


          <div className="info-card">

            <span className="info-icon">
              ⏱️
            </span>

            <h3>
              Dosificación automática
            </h3>

            <p>
              La cantidad solicitada se
              convierte en segundos de
              apertura del servo mediante
              la tasa de flujo calibrada.
            </p>

          </div>

        </div>

      </section>

    </main>
  );
}