from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    Integer,
)
from sqlalchemy.sql import func

from app.database import Base


class SensorData(Base):

    __tablename__ = "sensor_data"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    temperatura = Column(
        Float,
        nullable=False,
    )

    humedad = Column(
        Float,
        nullable=False,
    )

    luz_encendida = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    fecha_registro = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )