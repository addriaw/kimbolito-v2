"use client";

import {
  useCallback,
  useEffect,
  useState,
} from "react";

import {
  Activity,
  Gauge,
  RefreshCw,
  RotateCw,
  Timer,
  TrendingUp,
} from "lucide-react";

import {
  getLatestWheelActivity,
  getWheelToday,
  WheelActivity,
  WheelToday,
} from "@/lib/api";


export default function ActividadPage() {

  const [latest, setLatest] =
    useState<WheelActivity | null>(null);

  const [today, setToday] =
    useState<WheelToday | null>(null);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const [lastUpdate, setLastUpdate] =
    useState<Date | null>(null);


  const loadData = useCallback(
    async () => {

      try {

        setError("");

        const [
          latestData,
          todayData,
        ] = await Promise.all([
          getLatestWheelActivity(),
          getWheelToday(),
        ]);

        setLatest(latestData);

        setToday(todayData);

        setLastUpdate(
          new Date()
        );

      } catch (err) {

        setError(
          err instanceof Error
            ? err.message
            : "No se pudo obtener la actividad."
        );

      } finally {

        setLoading(false);

      }

    },
    []
  );


  useEffect(() => {

    loadData();

    const interval =
      setInterval(
        loadData,
        5000
      );

    return () => {
      clearInterval(interval);
    };

  }, [loadData]);


  function formatSeconds(
    seconds: number
  ) {

    const total =
      Math.max(
        0,
        Math.round(seconds)
      );

    const hours =
      Math.floor(total / 3600);

    const minutes =
      Math.floor(
        (total % 3600) / 60
      );

    const secs =
      total % 60;

    if (hours > 0) {

      return `${hours}h ${minutes}m`;

    }

    if (minutes > 0) {

      return `${minutes}m ${secs}s`;

    }

    return `${secs}s`;
  }


  return (

    <main className="activity-page">

      <section className="page-header">

        <div>

          <span className="eyebrow">
            ACTIVIDAD
          </span>

          <h1>
            Actividad física
          </h1>

          <p>
            Monitorea la actividad de la rueda
            en tiempo real.
          </p>

        </div>


        <button
          className="refresh-button"
          onClick={loadData}
          disabled={loading}
        >

          <RefreshCw
            size={16}
            className={
              loading
                ? "spin"
                : ""
            }
          />

          Actualizar

        </button>

      </section>


      {error && (

        <div className="monitoring-error">

          <strong>
            No hay conexión con la rueda
          </strong>

          <p>
            {error}
          </p>

        </div>

      )}


      <section className="activity-highlight">

        <div className="activity-highlight-icon">
          <Activity size={32} />
        </div>


        <div>

          <span>
            DISTANCIA RECORRIDA HOY
          </span>

          <strong>

            {today
              ? today.distance_m.toFixed(2)
              : "--"}

            <small>
              {" "}m
            </small>

          </strong>

          <p>
            Actividad registrada durante el día
          </p>

        </div>

      </section>


      <section className="activity-grid">


        {/* VUELTAS */}

        <article className="activity-card">

          <div className="activity-card-icon">
            <RotateCw size={21} />
          </div>

          <span>
            VUELTAS HOY
          </span>

          <strong>
            {today
              ? today.revolutions.toLocaleString(
                  "es-EC"
                )
              : "--"}
          </strong>

          <small>
            vueltas registradas
          </small>

        </article>


        {/* TIEMPO */}

        <article className="activity-card">

          <div className="activity-card-icon">
            <Timer size={21} />
          </div>

          <span>
            TIEMPO ACTIVO
          </span>

          <strong>
            {today
              ? formatSeconds(
                  today.active_minutes * 60
                )
              : "--"}
          </strong>

          <small>
            actividad acumulada
          </small>

        </article>


        {/* VELOCIDAD */}

        <article className="activity-card">

          <div className="activity-card-icon">
            <Gauge size={21} />
          </div>

          <span>
            VELOCIDAD MÁXIMA
          </span>

          <strong>

            {today
              ? today.max_speed_cm_s.toFixed(1)
              : "--"}

            <small>
              {" "}cm/s
            </small>

          </strong>

          <small>
            máximo registrado
          </small>

        </article>


        {/* ESTADO */}

        <article className="activity-card">

          <div className="activity-card-icon">
            <TrendingUp size={21} />
          </div>

          <span>
            ESTADO ACTUAL
          </span>

          <strong
            className={
              latest?.movement_detected
                ? "activity-online"
                : "activity-idle"
            }
          >
            {latest?.movement_detected
              ? "Activo"
              : "Reposo"}
          </strong>

          <small>
            {latest
              ? `${latest.speed_cm_s.toFixed(1)} cm/s`
              : "--"}
          </small>

        </article>

      </section>


      <section className="activity-detail-card">

        <div className="info-card-header">

          <div>

            <span className="eyebrow">
              TIEMPO REAL
            </span>

            <h2>
              Estado de la rueda
            </h2>

          </div>

          <div className="live-indicator">

            <span />

            En vivo

          </div>

        </div>


        <div className="activity-detail-grid">

          <div>

            <span>
              Vueltas acumuladas
            </span>

            <strong>
              {latest
                ? latest.revolutions_total.toLocaleString(
                    "es-EC"
                  )
                : "--"}
            </strong>

          </div>


          <div>

            <span>
              Distancia acumulada
            </span>

            <strong>
              {latest
                ? `${latest.distance_m_total.toFixed(2)} m`
                : "--"}
            </strong>

          </div>


          <div>

            <span>
              Velocidad
            </span>

            <strong>
              {latest
                ? `${latest.speed_cm_s.toFixed(1)} cm/s`
                : "--"}
            </strong>

          </div>


          <div>

            <span>
              Última actualización
            </span>

            <strong>
              {lastUpdate
                ? lastUpdate.toLocaleTimeString(
                    "es-EC"
                  )
                : "--"}
            </strong>

          </div>

        </div>

      </section>

    </main>
  );
}