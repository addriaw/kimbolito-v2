"use client";

import {
  useCallback,
  useEffect,
  useState,
} from "react";

import {
  getLatestSensor,
  SensorData,
} from "@/lib/api";
import { MessageCircle } from "lucide-react";

export default function MonitoreoPage() {

  // =====================================================
  // ESTADO
  // =====================================================

  const [sensor, setSensor] =
    useState<SensorData | null>(null);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const [lastUpdate, setLastUpdate] =
    useState<Date | null>(null);


  // =====================================================
  // RANGOS DEL SISTEMA
  // =====================================================

  const TEMP_MIN = 18;
  const TEMP_MAX = 35;

  const HUM_MIN = 40;
  const HUM_MAX = 80;


  // =====================================================
  // CARGAR DATOS
  // =====================================================

  const loadSensorData =
    useCallback(async () => {

      try {

        setError("");

        const data =
          await getLatestSensor();

        setSensor(data);

        setLastUpdate(
          new Date()
        );

      } catch (err) {

        console.error(
          "Error obteniendo sensores:",
          err
        );

        setError(
          err instanceof Error
            ? err.message
            : "No se pudieron obtener los datos."
        );

      } finally {

        setLoading(false);
      }

    }, []);


  // =====================================================
  // ACTUALIZACIÓN AUTOMÁTICA
  // =====================================================

useEffect(() => {

  loadSensorData();

  const interval =
    setInterval(
      loadSensorData,
      30000
    );

  return () =>
    clearInterval(interval);

}, [loadSensorData]);


  // =====================================================
  // TEMPERATURA
  // =====================================================

  const temperatureAlert =
    sensor !== null &&
    (
      sensor.temperatura < TEMP_MIN ||
      sensor.temperatura > TEMP_MAX
    );


  // =====================================================
  // HUMEDAD
  // =====================================================

  const humidityAlert =
    sensor !== null &&
    (
      sensor.humedad < HUM_MIN ||
      sensor.humedad > HUM_MAX
    );


  // =====================================================
  // FORMATEAR FECHA
  // =====================================================

  function formatDate(
    value?: string | null
  ) {

    if (!value) {
      return "--";
    }

    try {

      return new Date(
        value
      ).toLocaleString(
        "es-EC",
        {
          dateStyle: "medium",
          timeStyle: "medium",
        }
      );

    } catch {

      return "--";
    }
  }


  // =====================================================
  // ESTADO DE LUZ
  // =====================================================

  const lightStatus =
    sensor?.luz_encendida
      ? "Encendida"
      : "Apagada";


  // =====================================================
  // WHATSAPP
  // =====================================================

  function sendWhatsApp() {

    if (!sensor) {

      return;
    }


    const temperature =
      sensor.temperatura.toFixed(1);

    const humidity =
      sensor.humedad.toFixed(1);


    const temperatureState =
      temperatureAlert
        ? "⚠️ Fuera de rango"
        : "✅ Normal";


    const humidityState =
      humidityAlert
        ? "⚠️ Fuera de rango"
        : "✅ Normal";


    const message = `🐹 KIMBOLITO

📊 Estado del monitoreo

🌡️ Temperatura:
${temperature} °C
${temperatureState}

💧 Humedad:
${humidity} %
${humidityState}

💡 Luz:
${lightStatus}

🕐 Última lectura:
${formatDate(
  sensor.fecha_registro
)}

Sistema de monitoreo Hamster IoT.`;


    const url =
      `https://wa.me/?text=${encodeURIComponent(
        message
      )}`;


    window.open(
      url,
      "_blank"
    );
  }


  // =====================================================
  // RENDER
  // =====================================================

  return (

    <main className="monitoring-page">

      {/* =================================================
          ENCABEZADO
      ================================================= */}

      <section className="monitoring-header">

        <div>

          <span className="eyebrow">
            MONITOREO
          </span>

          <h1>
            Estado ambiental
          </h1>

          <p>
            Consulta en tiempo real las
            condiciones del entorno del hamster.
          </p>

        </div>


        <button
          className="refresh-button"
          onClick={loadSensorData}
          disabled={loading}
        >

          ↻

          <span>
            Actualizar
          </span>

        </button>

      </section>


      {/* =================================================
          ERROR
      ================================================= */}

      {error && (

        <div className="monitoring-error">

          <span>
            ⚠️
          </span>

          <div>

            <strong>
              No se pudo actualizar
            </strong>

            <p>
              {error}
            </p>

          </div>

        </div>

      )}


      {/* =================================================
          CARGANDO
      ================================================= */}

      {loading && !sensor ? (

        <section className="monitoring-loading">

          <div className="loading-spinner" />

          <p>
            Obteniendo información...
          </p>

        </section>

      ) : !sensor ? (

        /* =================================================
           SIN DATOS
        ================================================= */

        <section className="monitoring-empty">

          <div className="empty-icon">
            📡
          </div>

          <h2>
            Sin datos disponibles
          </h2>

          <p>
            Todavía no se ha recibido ninguna
            lectura de los sensores.
          </p>

          <button
            className="primary-button"
            onClick={loadSensorData}
          >
            Intentar nuevamente
          </button>

        </section>

      ) : (

        <>

          {/* ===============================================
              TARJETAS DE SENSORES
          =============================================== */}

          <section className="sensor-grid">


            {/* TEMPERATURA */}

            <article
              className={
                temperatureAlert
                  ? "sensor-card alert"
                  : "sensor-card"
              }
            >

              <div className="sensor-card-top">

                <div className="sensor-icon temperature">
                  🌡️
                </div>

                <span
                  className={
                    temperatureAlert
                      ? "sensor-state alert"
                      : "sensor-state normal"
                  }
                >

                  {temperatureAlert
                    ? "Fuera de rango"
                    : "Normal"}

                </span>

              </div>


              <span className="sensor-label">
                Temperatura
              </span>


              <div className="sensor-value">

                {sensor.temperatura.toFixed(1)}

                <span>
                  °C
                </span>

              </div>


              <div className="sensor-range">

                <span>
                  Mín. {TEMP_MIN} °C
                </span>

                <span>
                  Máx. {TEMP_MAX} °C
                </span>

              </div>

            </article>


            {/* HUMEDAD */}

            <article
              className={
                humidityAlert
                  ? "sensor-card alert"
                  : "sensor-card"
              }
            >

              <div className="sensor-card-top">

                <div className="sensor-icon humidity">
                  💧
                </div>

                <span
                  className={
                    humidityAlert
                      ? "sensor-state alert"
                      : "sensor-state normal"
                  }
                >

                  {humidityAlert
                    ? "Fuera de rango"
                    : "Normal"}

                </span>

              </div>


              <span className="sensor-label">
                Humedad
              </span>


              <div className="sensor-value">

                {sensor.humedad.toFixed(1)}

                <span>
                  %
                </span>

              </div>


              <div className="sensor-range">

                <span>
                  Mín. {HUM_MIN} %
                </span>

                <span>
                  Máx. {HUM_MAX} %
                </span>

              </div>

            </article>


            {/* LUZ */}

            <article className="sensor-card">

              <div className="sensor-card-top">

                <div className="sensor-icon light">
                  💡
                </div>

                <span className="sensor-state normal">
                  Automática
                </span>

              </div>


              <span className="sensor-label">
                Iluminación
              </span>


              <div className="sensor-value light-value">

                {lightStatus}

              </div>


              <div className="sensor-range">

                <span>
                  Control mediante LDR
                </span>

              </div>

            </article>

          </section>


          {/* ===============================================
              INFORMACIÓN
          =============================================== */}

          <section className="monitoring-info">


            <div className="info-card">

              <div className="info-card-header">

                <div>

                  <span className="eyebrow">
                    INFORMACIÓN
                  </span>

                  <h2>
                    Última lectura
                  </h2>

                </div>

                <span className="live-indicator">
                  <span />
                  Actualizado
                </span>

              </div>


              <div className="info-grid">

                <div className="info-item">

                  <span>
                    Temperatura
                  </span>

                  <strong>
                    {sensor.temperatura.toFixed(1)}
                    °C
                  </strong>

                </div>


                <div className="info-item">

                  <span>
                    Humedad
                  </span>

                  <strong>
                    {sensor.humedad.toFixed(1)}
                    %
                  </strong>

                </div>


                <div className="info-item">

                  <span>
                    Luz
                  </span>

                  <strong>
                    {lightStatus}
                  </strong>

                </div>


                <div className="info-item">

                  <span>
                    Fecha de lectura
                  </span>

                  <strong>
                    {formatDate(
                      sensor.fecha_registro
                    )}
                  </strong>

                </div>

              </div>

            </div>


            {/* =============================================
                WHATSAPP
            ============================================= */}

            <div className="whatsapp-card">

              <div className="whatsapp-icon">
                📱
              </div>


              <div className="whatsapp-content">

                <h2>
                  Compartir estado
                </h2>

                <p>
                  Envía por WhatsApp el estado
                  actual del monitoreo.
                </p>

              </div>


              <button
                className="whatsapp-button"
                onClick={sendWhatsApp}
              >

                📱

                <span>
                  Enviar por WhatsApp
                </span>

              </button>

            </div>

          </section>


          {/* ===============================================
              ACTUALIZACIÓN
          =============================================== */}

          <div className="monitoring-footer">

            <span>
              Actualización automática cada 5 segundos
            </span>

            <span>
              Última consulta:
              {" "}
              {lastUpdate
                ? lastUpdate.toLocaleTimeString(
                    "es-EC"
                  )
                : "--"}
            </span>

          </div>

        </>

      )}

    </main>
  );
}