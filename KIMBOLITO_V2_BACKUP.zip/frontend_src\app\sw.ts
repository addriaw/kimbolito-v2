import { defaultCache } from "@serwist/next/worker";

import type {
  PrecacheEntry,
  SerwistGlobalConfig,
} from "serwist";

import {
  Serwist,
} from "serwist";


declare global {

  interface WorkerGlobalScope
    extends SerwistGlobalConfig {

    __SW_MANIFEST:
      | (PrecacheEntry | string)[]
      | undefined;
  }
}


declare const self:
  ServiceWorkerGlobalScope;


// =========================================================
// SERWIST
// =========================================================

const serwist =
  new Serwist({

    precacheEntries:
      self.__SW_MANIFEST,

    skipWaiting:
      true,

    clientsClaim:
      true,

    runtimeCaching:
      defaultCache,
  });


serwist.addEventListeners();


// =========================================================
// PUSH NOTIFICATIONS
// =========================================================

self.addEventListener(
  "push",
  (event) => {

    if (!event.data) {

      return;
    }


    let data: {

      title?: string;

      message?: string;

      type?: string;

      severity?: string;

    };


    try {

      data =
        event.data.json();

    } catch {

      data = {

        title:
          "KIMBOLITO",

        message:
          event.data.text(),

      };
    }


    const title =
      data.title
      || "KIMBOLITO";


    const message =
      data.message
      || "Nueva notificación.";


    const options:
      NotificationOptions = {

        body: message,

        tag:
          data.type
          || "hamster-iot",

        icon:
          "/icons/icon-192.png",

        badge:
          "/icons/icon-192.png",

        data: {

          type:
            data.type
            || "GENERAL",

        },
      };


    event.waitUntil(

      self.registration
        .showNotification(
          title,
          options
        )

    );

  }
);


// =========================================================
// CLICK EN NOTIFICACIÓN
// =========================================================

self.addEventListener(
  "notificationclick",
  (event) => {

    event.notification.close();


    event.waitUntil(

      self.clients
        .matchAll({
          type: "window",
          includeUncontrolled: true,
        })
        .then(
          (clientList) => {

            for (
              const client
              of clientList
            ) {

              if (
                "focus" in client
              ) {

                return client.focus();
              }
            }


            if (
              self.clients.openWindow
            ) {

              return self.clients
                .openWindow(
                  "/"
                );
            }

          }
        )

    );

  }
);