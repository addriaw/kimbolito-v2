from datetime import datetime

from pydantic import BaseModel, Field


class FeedingCalculationRequest(BaseModel):
    food_id: int
    grams: float = Field(gt=0)


class FeedingCalculationResponse(BaseModel):
    food_id: int
    grams: float
    flow_rate: float
    duration_seconds: float


class FeedingRequest(BaseModel):
    food_id: int
    grams: float = Field(gt=0)


class FeedingResponse(BaseModel):
    id: int
    food_id: int
    food_name: str
    grams: float
    duration_seconds: float
    feeding_type: str
    status: str
    created_at: datetime


class FeedingConsumptionResponse(BaseModel):
    total_grams: float
    total_feedings: int