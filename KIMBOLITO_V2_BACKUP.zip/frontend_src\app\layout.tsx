import type {
  Metadata,
  Viewport,
} from "next";

import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";

import "./globals.css";


export const metadata: Metadata = {

  title: "kIMBOLITO",

  description:
    "Sistema IoT de monitoreo ambiental y alimentación automática para pequeños animales.",

  manifest:
    "/manifest.webmanifest",
};


export const viewport: Viewport = {

  width:
    "device-width",

  initialScale:
    1,

  viewportFit:
    "cover",

  themeColor:
    "#1f7a5a",
};


export default function RootLayout({
  children,
}: Readonly<{
  children:
    React.ReactNode;
}>) {

  return (

    <html lang="es">

      <body>

        <div className="app-layout">

          <Sidebar />

          <main className="main-container">

            <Header />

            {children}

          </main>

        </div>

      </body>

    </html>
  );
}