from urllib.parse import quote


def generate_feeding_message(
    food_name: str,
    grams: float,
    duration_seconds: float,
    feeding_type: str,
    feeding_id: int,
) -> str:

    type_names = {
        "MANUAL": "Alimentación manual",
        "TEST": "Prueba de alimentación",
        "SCHEDULED": "Alimentación programada",
    }

    feeding_name = type_names.get(
        feeding_type,
        feeding_type,
    )

    message = (
        "🐹 KIMBOLITO\n\n"
        f"🍽️ {feeding_name}\n\n"
        f"📋 Registro: #{feeding_id}\n"
        f"🌾 Alimento: {food_name}\n"
        f"⚖️ Cantidad estimada: {grams} g\n"
        f"⏱️ Tiempo de apertura: "
        f"{duration_seconds:.2f} segundos\n\n"
        "✅ Acción registrada correctamente."
    )

    return message


def generate_whatsapp_url(
    message: str,
    phone_number: str | None = None,
) -> str:

    encoded_message = quote(message)

    if phone_number:
        clean_phone = (
            phone_number
            .replace("+", "")
            .replace(" ", "")
            .replace("-", "")
        )

        return (
            f"https://wa.me/{clean_phone}"
            f"?text={encoded_message}"
        )

    return (
        f"https://wa.me/"
        f"?text={encoded_message}"
    )