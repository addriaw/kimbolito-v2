"use client";

import { useEffect, useRef, useState } from "react";
import { Bell, Menu } from "lucide-react";
import { getNotifications, getUnreadNotificationCount } from "@/lib/api";

type AppNotification = {
  id: number;
  type: string;
  title: string;
  message: string;
  severity: "INFO" | "SUCCESS" | "WARNING" | "ERROR";
  is_read: boolean;
  created_at: string;
};

function showBrowserNotification(notification: AppNotification) {
  if (typeof window === "undefined") return;
  if (!("Notification" in window)) return;
  if (window.Notification.permission !== "granted") return;

  try {
    const browserNotification = new window.Notification(
      notification.title,
      {
        body: notification.message,
        tag: `hamster-${notification.id}`,
        icon: "/icons/icon-192.png",
        badge: "/icons/icon-192.png",
      }
    );

    browserNotification.onclick = () => {
      window.focus();
      browserNotification.close();
    };
  } catch (error) {
    console.error("No se pudo mostrar la notificación del navegador:", error);
  }
}

export default function Header() {
  const [unreadCount, setUnreadCount] = useState(0);
  const initializedRef = useRef(false);
  const lastNotificationIdRef = useRef<number | null>(null);

  useEffect(() => {
    let mounted = true;

    const loadNotifications = async () => {
      try {
        const [countResponse, notifications] = await Promise.all([
          getUnreadNotificationCount(),
          getNotifications(20),
        ]);

        if (!mounted) return;

        setUnreadCount(countResponse.count);

        if (!notifications.length) {
          initializedRef.current = true;
          return;
        }

        const newest = [...notifications].sort(
          (a, b) => b.id - a.id
        )[0];

        // Primera carga: solo sincronizamos, no mostramos las notificaciones antiguas.
        if (!initializedRef.current) {
          lastNotificationIdRef.current = newest.id;
          initializedRef.current = true;
          return;
        }

        // Mostrar cada notificación nueva creada en PostgreSQL.
        const lastId = lastNotificationIdRef.current ?? 0;
        const newNotifications = notifications
          .filter((notification) => notification.id > lastId)
          .sort((a, b) => a.id - b.id);

        for (const notification of newNotifications) {
          showBrowserNotification(notification);
          lastNotificationIdRef.current = notification.id;
        }
      } catch (error) {
        console.error(
          "Error obteniendo notificaciones:",
          error
        );
      }
    };

    loadNotifications();

    // V2: PostgreSQL + polling.
    const intervalId = window.setInterval(
      loadNotifications,
      10000
    );

    return () => {
      mounted = false;
      window.clearInterval(intervalId);
    };
  }, []);

  async function enableBrowserNotifications() {
    if (
      typeof window === "undefined" ||
      !("Notification" in window)
    ) {
      return;
    }

    if (window.Notification.permission === "default") {
      try {
        await window.Notification.requestPermission();
      } catch (error) {
        console.error(
          "No se pudo solicitar permiso de notificaciones:",
          error
        );
      }
    }
  }

  return (
    <header className="top-header">
      <div className="mobile-menu">
        <Menu size={23} />
      </div>

      <div className="header-title">
        <span>Panel de control</span>
        <h2>Inicio</h2>
      </div>

      <div className="header-actions">
        <button
          type="button"
          className="header-button"
          aria-label={
            unreadCount > 0
              ? `${unreadCount} notificaciones sin leer`
              : "Notificaciones"
          }
          title={
            unreadCount > 0
              ? `${unreadCount} notificaciones sin leer`
              : "Notificaciones"
          }
          onClick={enableBrowserNotifications}
        >
          <Bell size={20} />

          {unreadCount > 0 && (
            <span className="notification-dot">
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
}
