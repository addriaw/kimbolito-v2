from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec


# =========================================================
# GENERAR CLAVES VAPID
# =========================================================

private_key = ec.generate_private_key(
    ec.SECP256R1()
)

public_key = private_key.public_key()


# =========================================================
# GUARDAR CLAVE PRIVADA
# =========================================================

private_pem = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption(),
)

with open(
    "vapid_private.pem",
    "wb",
) as file:

    file.write(
        private_pem
    )


# =========================================================
# GUARDAR CLAVE PÚBLICA
# =========================================================

public_pem = public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo,
)

with open(
    "vapid_public.pem",
    "wb",
) as file:

    file.write(
        public_pem
    )


print("")
print("======================================")
print("      VAPID GENERADO CORRECTAMENTE")
print("======================================")
print("")
print("Archivo privado:")
print("  vapid_private.pem")
print("")
print("Archivo público:")
print("  vapid_public.pem")
print("")