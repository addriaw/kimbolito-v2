"use client";
import {
  useEffect,
  useState,
} from "react";

import { MessageCircle } from "lucide-react";

import {
  FeedingRecord,
  Consumption,
  getFeedingHistory,
  getWhatsAppFeeding,
  getConsumption,
} from "@/lib/api";


export default function HistorialPage() {

  const [records, setRecords] =
    useState<FeedingRecord[]>([]);

  const [consumption, setConsumption] =
    useState<Consumption | null>(null);

  const [filter, setFilter] =
    useState("ALL");

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");


    /// whatsApp
  const handleWhatsApp = async (feedingId: number) => {
  try {
    const data = await getWhatsAppFeeding(feedingId);

    window.open(
      data.whatsapp_url,
      "_blank",
      "noopener,noreferrer"
    );

    

  } catch (error) {
    console.error(
      "Error generando mensaje de WhatsApp:",
      error
    );

    alert(
      "No se pudo generar el mensaje de WhatsApp."
    );
  }
};
  // =====================================================
  // CARGAR
  // =====================================================

  useEffect(() => {

    loadHistory();

  }, []);


  async function loadHistory() {

    try {

      setLoading(true);

      const [
        history,
        consumptionData,
      ] = await Promise.all([
        getFeedingHistory(),
        getConsumption(),
      ]);

      setRecords(history);

      setConsumption(
        consumptionData
      );

    } catch (err) {

      setError(
        err instanceof Error
          ? err.message
          : "No se pudo cargar el histórico."
      );

    } finally {

      setLoading(false);
    }
  }


  

  // =====================================================
  // FILTRAR
  // =====================================================

  const filteredRecords =
    filter === "ALL"
      ? records
      : records.filter(
          record =>
            record.feeding_type === filter
        );


  // =====================================================
  // ESTADO
  // =====================================================

  function statusLabel(
    status: string
  ) {

    switch (status) {

      case "SUCCESS":
        return "Completada";

      case "RUNNING":
        return "En proceso";

      case "PENDING":
        return "Pendiente";

      case "FAILED":
        return "Fallida";

      default:
        return status;
    }
  }


  function statusClass(
    status: string
  ) {

    switch (status) {

      case "SUCCESS":
        return "status-success";

      case "RUNNING":
        return "status-running";

      case "FAILED":
        return "status-failed";

      default:
        return "status-pending";
    }
  }


  function typeLabel(
    type: string
  ) {

    switch (type) {

      case "MANUAL":
        return "Manual";

      case "TEST":
        return "Prueba";

      case "SCHEDULED":
        return "Programada";

      default:
        return type;
    }
  }


  function formatDate(
    value: string
  ) {

    return new Date(
      value
    ).toLocaleString(
      "es-EC",
      {
        dateStyle: "short",
        timeStyle: "short",
      }
    );
  }


  return (

    <main className="history-page">

      {/* =================================================
          HEADER
      ================================================= */}

      <section className="history-header">

        <div>

          <span className="eyebrow">
            HISTÓRICO
          </span>

          <h1>
            Alimentaciones
          </h1>

          <p>
            Consulta todas las acciones
            realizadas por el sistema.
          </p>

        </div>

      </section>


      {/* =================================================
          RESUMEN
      ================================================= */}

      <section className="history-summary">

        <div className="summary-card">

          <span>
            Consumo registrado
          </span>

          <strong>
            {consumption?.total_grams ?? 0}
            {" "}
            g
          </strong>

        </div>


        <div className="summary-card">

          <span>
            Alimentaciones
          </span>

          <strong>
            {consumption?.total_feedings ?? 0}
          </strong>

        </div>

      </section>


      {/* =================================================
          FILTROS
      ================================================= */}

      <section className="history-controls">

        <button
          className={
            filter === "ALL"
              ? "filter-button active"
              : "filter-button"
          }
          onClick={() =>
            setFilter("ALL")
          }
        >
          Todas
        </button>

        <button
          className={
            filter === "MANUAL"
              ? "filter-button active"
              : "filter-button"
          }
          onClick={() =>
            setFilter("MANUAL")
          }
        >
          Manuales
        </button>

        <button
          className={
            filter === "SCHEDULED"
              ? "filter-button active"
              : "filter-button"
          }
          onClick={() =>
            setFilter("SCHEDULED")
          }
        >
          Programadas
        </button>

        <button
          className={
            filter === "TEST"
              ? "filter-button active"
              : "filter-button"
          }
          onClick={() =>
            setFilter("TEST")
          }
        >
          Pruebas
        </button>

      </section>


      {/* =================================================
          ERROR
      ================================================= */}

      {error && (

        <div className="error-message">
          {error}
        </div>

      )}


      {/* =================================================
          HISTÓRICO
      ================================================= */}

      {loading ? (

        <div className="empty-state">

          <div className="loading-spinner" />

          <p>
            Cargando histórico...
          </p>

        </div>

      ) : filteredRecords.length === 0 ? (

        <div className="empty-state">

          <div className="empty-icon">
            📜
          </div>

          <h3>
            No hay registros
          </h3>

          <p>
            Las alimentaciones aparecerán
            aquí automáticamente.
          </p>

        </div>

      ) : (

        <section className="history-list">

          {filteredRecords.map(
            record => (

         <article
  className="history-card"
  key={record.id}
>
  <div className="history-icon">
    {record.feeding_type === "TEST"
      ? "🧪"
      : "🍽️"}
  </div>

  <div className="history-main">
    <div className="history-title">
      <h3>
        {record.food_name}
      </h3>

      <span
        className={
          statusClass(record.status)
        }
      >
        •{" "}
        {statusLabel(record.status)}
      </span>
    </div>

    <div className="history-details">
      <span>
        {record.grams} g
      </span>

      <span>
        {record.duration_seconds} s
      </span>

      <span>
        {typeLabel(record.feeding_type)}
      </span>
    </div>
  </div>

  <div className="history-date">
    {formatDate(record.created_at)}
  </div>

  <button
    type="button"
    className="whatsapp-button"
    onClick={() =>
      handleWhatsApp(record.id)
    }
    title="Compartir por WhatsApp"
    aria-label="Compartir por WhatsApp"
  >
    <MessageCircle
      size={18}
      strokeWidth={2.2}
    />
  </button>
</article>

            )
          )}

        </section>

      )}

    </main>
  );
}