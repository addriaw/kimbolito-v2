from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.feeding import FeedingRecord
from app.models.food import Food
from app.services.whatsapp_service import (
    generate_feeding_message,
    generate_whatsapp_url,
)


router = APIRouter(
    prefix="/api/whatsapp",
    tags=["WhatsApp"],
)


@router.get("/feeding/{feeding_id}")
def whatsapp_feeding(
    feeding_id: int,
    db: Session = Depends(get_db),
):

    result = (
        db.query(
            FeedingRecord,
            Food.name,
        )
        .join(
            Food,
            FeedingRecord.food_id == Food.id,
        )
        .filter(
            FeedingRecord.id == feeding_id
        )
        .first()
    )

    if not result:
        raise HTTPException(
            status_code=404,
            detail="Registro de alimentación no encontrado.",
        )

    record, food_name = result

    message = generate_feeding_message(
        food_name=food_name,
        grams=record.grams,
        duration_seconds=record.duration_seconds,
        feeding_type=record.feeding_type,
        feeding_id=record.id,
    )

    whatsapp_url = generate_whatsapp_url(
        message
    )

    return {
        "feeding_id": record.id,
        "message": message,
        "whatsapp_url": whatsapp_url,
    }