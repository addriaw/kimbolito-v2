def calculate_duration(
    grams: float,
    flow_rate: float,
) -> float:

    if grams <= 0:
        raise ValueError(
            "La cantidad debe ser mayor que 0 gramos."
        )

    if flow_rate <= 0:
        raise ValueError(
            "La tasa de flujo debe ser mayor que 0."
        )

    duration = grams / flow_rate

    return round(
        duration,
        2,
    )