from sqlalchemy import (
    Boolean,
    Column,
    Date,
    Integer,
    String,
    Time,
    Float,
    DateTime,
)
from sqlalchemy.sql import func

from app.database import Base


class FeedingSchedule(Base):

    __tablename__ = "feeding_schedules"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    food_id = Column(
        Integer,
        nullable=False,
    )

    grams = Column(
        Float,
        nullable=False,
    )

    feeding_time = Column(
        Time,
        nullable=False,
    )

    # =============================================
    # DÍAS DE LA SEMANA
    # =============================================

    monday = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    tuesday = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    wednesday = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    thursday = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    friday = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    saturday = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    sunday = Column(
        Boolean,
        default=False,
        nullable=False,
    )

    # =============================================
    # RANGO DE FECHAS
    # =============================================

    start_date = Column(
        Date,
        nullable=True,
    )

    end_date = Column(
        Date,
        nullable=True,
    )

    # =============================================
    # ESTADO
    # =============================================

    active = Column(
        Boolean,
        default=True,
        nullable=False,
    )

    last_executed_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        default=func.now(),
        server_default=func.now(),
        nullable=False,
    )