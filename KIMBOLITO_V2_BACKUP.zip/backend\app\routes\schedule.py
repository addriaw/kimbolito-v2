from datetime import date

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
)

from sqlalchemy.orm import Session

from app.database import get_db
from app.models.food import Food
from app.models.schedule import FeedingSchedule
from app.schemas.schedule import (
    ScheduleCreate,
    ScheduleResponse,
)


router = APIRouter(
    prefix="/api/schedules",
    tags=["Programaciones"],
)


# =========================================================
# OBTENER PROGRAMACIONES
# =========================================================

@router.get(
    "",
    response_model=list[ScheduleResponse],
)
def get_schedules(
    db: Session = Depends(get_db),
):

    schedules = (
        db.query(FeedingSchedule)
        .order_by(
            FeedingSchedule.feeding_time.asc()
        )
        .all()
    )

    return schedules


# =========================================================
# OBTENER UNA PROGRAMACIÓN
# =========================================================

@router.get(
    "/{schedule_id}",
    response_model=ScheduleResponse,
)
def get_schedule(
    schedule_id: int,
    db: Session = Depends(get_db),
):

    schedule = (
        db.query(FeedingSchedule)
        .filter(
            FeedingSchedule.id == schedule_id
        )
        .first()
    )

    if not schedule:

        raise HTTPException(
            status_code=404,
            detail="Programación no encontrada.",
        )

    return schedule


# =========================================================
# CREAR PROGRAMACIÓN
# =========================================================

@router.post(
    "",
    response_model=ScheduleResponse,
    status_code=201,
)
def create_schedule(
    request: ScheduleCreate,
    db: Session = Depends(get_db),
):

    # -----------------------------------------------------
    # VALIDAR ALIMENTO
    # -----------------------------------------------------

    food = (
        db.query(Food)
        .filter(
            Food.id == request.food_id
        )
        .first()
    )

    if not food:

        raise HTTPException(
            status_code=404,
            detail="El alimento seleccionado no existe.",
        )


    # -----------------------------------------------------
    # VALIDAR FECHAS
    # -----------------------------------------------------

    if (
        request.start_date
        and request.end_date
        and request.end_date < request.start_date
    ):

        raise HTTPException(
            status_code=400,
            detail=(
                "La fecha final no puede ser "
                "anterior a la fecha inicial."
            ),
        )


    # -----------------------------------------------------
    # VALIDAR DÍAS
    # -----------------------------------------------------

    days = [
        request.monday,
        request.tuesday,
        request.wednesday,
        request.thursday,
        request.friday,
        request.saturday,
        request.sunday,
    ]

    if not any(days):

        raise HTTPException(
            status_code=400,
            detail=(
                "La programación debe tener "
                "al menos un día seleccionado."
            ),
        )


    # -----------------------------------------------------
    # CREAR
    # -----------------------------------------------------

    schedule = FeedingSchedule(

        food_id=request.food_id,

        grams=request.grams,

        feeding_time=request.feeding_time,

        monday=request.monday,
        tuesday=request.tuesday,
        wednesday=request.wednesday,
        thursday=request.thursday,
        friday=request.friday,
        saturday=request.saturday,
        sunday=request.sunday,

        start_date=request.start_date,

        end_date=request.end_date,

        active=request.active,
    )


    db.add(schedule)

    db.commit()

    db.refresh(schedule)


    return schedule


# =========================================================
# ACTIVAR / DESACTIVAR
# =========================================================

@router.patch(
    "/{schedule_id}/toggle",
    response_model=ScheduleResponse,
)
def toggle_schedule(
    schedule_id: int,
    db: Session = Depends(get_db),
):

    schedule = (
        db.query(FeedingSchedule)
        .filter(
            FeedingSchedule.id == schedule_id
        )
        .first()
    )

    if not schedule:

        raise HTTPException(
            status_code=404,
            detail="Programación no encontrada.",
        )


    schedule.active = not schedule.active

    db.commit()

    db.refresh(schedule)


    return schedule


# =========================================================
# ELIMINAR PROGRAMACIÓN
# =========================================================

@router.delete(
    "/{schedule_id}",
    status_code=204,
)
def delete_schedule(
    schedule_id: int,
    db: Session = Depends(get_db),
):

    schedule = (
        db.query(FeedingSchedule)
        .filter(
            FeedingSchedule.id == schedule_id
        )
        .first()
    )

    if not schedule:

        raise HTTPException(
            status_code=404,
            detail="Programación no encontrada.",
        )


    db.delete(schedule)

    db.commit()


    return None