from datetime import datetime
import threading

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.food import Food
from app.models.feeding import FeedingRecord
from app.schemas.feeding import (
    FeedingCalculationRequest,
    FeedingCalculationResponse,
    FeedingRequest,
    FeedingResponse,
    FeedingConsumptionResponse,
)
from app.services.feeding_service import calculate_duration
from app.services.mqtt_service import publish_feeding
from app.services.notification_service import notify_feeding_success


router = APIRouter(
    prefix="/api/feeding",
    tags=["Alimentación"],
)


# =========================================================
# BLOQUEO DE ALIMENTACIÓN
# =========================================================

feeding_lock = threading.Lock()

feeding_in_progress = False


# =========================================================
# CALCULAR TIEMPO
# =========================================================

@router.post(
    "/calculate",
    response_model=FeedingCalculationResponse,
)
def calculate_feeding(
    request: FeedingCalculationRequest,
    db: Session = Depends(get_db),
):

    food = (
        db.query(Food)
        .filter(Food.id == request.food_id)
        .first()
    )

    if not food:

        raise HTTPException(
            status_code=404,
            detail="Alimento no encontrado.",
        )

    if request.grams <= 0:

        raise HTTPException(
            status_code=400,
            detail="La cantidad debe ser mayor que 0 gramos.",
        )

    duration = calculate_duration(
        request.grams,
        food.flow_rate,
    )

    return {
        "food_id": food.id,
        "grams": request.grams,
        "flow_rate": food.flow_rate,
        "duration_seconds": duration,
    }


# =========================================================
# CREAR ALIMENTACIÓN
# =========================================================

def create_feeding(
    request: FeedingRequest,
    feeding_type: str,
    db: Session,
):

    global feeding_in_progress

    # -----------------------------------------------------
    # VALIDACIÓN
    # -----------------------------------------------------

    if request.grams <= 0:

        raise HTTPException(
            status_code=400,
            detail="La cantidad debe ser mayor que 0 gramos.",
        )

    # -----------------------------------------------------
    # BLOQUEO
    # -----------------------------------------------------

    if feeding_in_progress:

        raise HTTPException(
            status_code=409,
            detail=(
                "Ya existe una alimentación en proceso. "
                "Espere a que termine antes de iniciar otra."
            ),
        )

    acquired = feeding_lock.acquire(
        blocking=False
    )

    if not acquired:

        raise HTTPException(
            status_code=409,
            detail="Otra alimentación está siendo procesada.",
        )

    try:

        feeding_in_progress = True

        # -------------------------------------------------
        # BUSCAR ALIMENTO
        # -------------------------------------------------

        food = (
            db.query(Food)
            .filter(Food.id == request.food_id)
            .first()
        )

        if not food:

            raise HTTPException(
                status_code=404,
                detail="Alimento no encontrado.",
            )

        # -------------------------------------------------
        # CALCULAR DURACIÓN
        # -------------------------------------------------

        duration = calculate_duration(
            request.grams,
            food.flow_rate,
        )

        # -------------------------------------------------
        # CREAR REGISTRO
        # -------------------------------------------------

        record = FeedingRecord(
            food_id=food.id,
            grams=request.grams,
            duration_seconds=duration,
            feeding_type=feeding_type,
            status="PENDING",
        )

        db.add(record)

        db.commit()

        db.refresh(record)

        # -------------------------------------------------
        # ENVIAR MQTT
        # -------------------------------------------------

        mqtt_sent = publish_feeding(
            feeding_id=record.id,
            duration_seconds=duration,
        )

        # -------------------------------------------------
        # ESTADO
        # -------------------------------------------------

        if mqtt_sent:

            record.status = "RUNNING"
            notify_feeding_success(
    db,
    record.id,
)

        else:

            record.status = "FAILED"

        db.commit()

        db.refresh(record)

        return {
            "id": record.id,
            "food_id": record.food_id,
            "food_name": food.name,
            "grams": record.grams,
            "duration_seconds": record.duration_seconds,
            "feeding_type": record.feeding_type,
            "status": record.status,
            "created_at": record.created_at,
        }

    finally:

        feeding_in_progress = False

        feeding_lock.release()


# =========================================================
# DAR COMIDA AHORA
# =========================================================

@router.post(
    "/manual",
    response_model=FeedingResponse,
)
def feed_now(
    request: FeedingRequest,
    db: Session = Depends(get_db),
):

    return create_feeding(
        request=request,
        feeding_type="MANUAL",
        db=db,
    )


# =========================================================
# PRUEBA
# =========================================================

@router.post(
    "/test",
    response_model=FeedingResponse,
)
def test_feeding(
    request: FeedingRequest,
    db: Session = Depends(get_db),
):

    return create_feeding(
        request=request,
        feeding_type="TEST",
        db=db,
    )


# =========================================================
# HISTÓRICO
# =========================================================

@router.get(
    "/history",
    response_model=list[FeedingResponse],
)
def feeding_history(
    feeding_type: str | None = Query(
        default=None
    ),

    status: str | None = Query(
        default=None
    ),

    limit: int = Query(
        default=100,
        ge=1,
        le=500,
    ),

    db: Session = Depends(get_db),
):

    query = (
        db.query(
            FeedingRecord,
            Food.name,
        )
        .join(
            Food,
            FeedingRecord.food_id == Food.id,
        )
    )

    # -----------------------------------------------------
    # FILTRO TIPO
    # -----------------------------------------------------

    if feeding_type:

        query = query.filter(
            FeedingRecord.feeding_type
            == feeding_type.upper()
        )

    # -----------------------------------------------------
    # FILTRO ESTADO
    # -----------------------------------------------------

    if status:

        query = query.filter(
            FeedingRecord.status
            == status.upper()
        )

    # -----------------------------------------------------
    # ORDEN
    # -----------------------------------------------------

    records = (
        query
        .order_by(
            FeedingRecord.created_at.desc()
        )
        .limit(limit)
        .all()
    )

    return [
        {
            "id": record.id,
            "food_id": record.food_id,
            "food_name": food_name,
            "grams": record.grams,
            "duration_seconds": record.duration_seconds,
            "feeding_type": record.feeding_type,
            "status": record.status,
            "created_at": record.created_at,
        }

        for record, food_name in records
    ]


# =========================================================
# OBTENER ALIMENTACIÓN POR ID
# =========================================================

@router.get(
    "/history/{feeding_id}",
    response_model=FeedingResponse,
)
def get_feeding(
    feeding_id: int,
    db: Session = Depends(get_db),
):

    result = (
        db.query(
            FeedingRecord,
            Food.name,
        )
        .join(
            Food,
            FeedingRecord.food_id == Food.id,
        )
        .filter(
            FeedingRecord.id == feeding_id
        )
        .first()
    )

    if not result:

        raise HTTPException(
            status_code=404,
            detail="Registro de alimentación no encontrado.",
        )

    record, food_name = result

    return {
        "id": record.id,
        "food_id": record.food_id,
        "food_name": food_name,
        "grams": record.grams,
        "duration_seconds": record.duration_seconds,
        "feeding_type": record.feeding_type,
        "status": record.status,
        "created_at": record.created_at,
    }


# =========================================================
# CONSUMO
# =========================================================

@router.get(
    "/consumption",
    response_model=FeedingConsumptionResponse,
)
def feeding_consumption(
    db: Session = Depends(get_db),
):

    records = (
        db.query(FeedingRecord)
        .filter(
            FeedingRecord.status.in_(
                [
                    "PENDING",
                    "RUNNING",
                    "SUCCESS",
                ]
            )
        )
        .all()
    )

    total_grams = sum(
        record.grams
        for record in records
    )

    return {
        "total_grams": round(
            total_grams,
            2,
        ),

        "total_feedings": len(
            records
        ),
    }