"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Sidebar() {
  const pathname = usePathname();

  const items = [
    {
      href: "/",
      label: "Inicio",
      icon: "⌂",
    },
    {
      href: "/alimentacion",
      label: "Alimentación",
      icon: "🍽️",
    },
    {
      href: "/programaciones",
      label: "Programaciones",
      icon: "⏰",
    },
    {
      href: "/historial",
      label: "Histórico",
      icon: "📜",
    },
    {
      href: "/monitoreo",
      label: "Monitoreo",
      icon: "🌡️",
    },
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <span className="logo-icon">🐹</span>

        <div>
          <strong>KIMBOLITO</strong>
          <span>Sistema de monitoreo</span>
        </div>
      </div>

      <nav className="sidebar-nav">
        {items.map((item) => {
          const isActive =
            pathname === item.href ||
            (item.href !== "/" && pathname.startsWith(item.href));

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`sidebar-link ${isActive ? "active" : ""}`}
            >
              <span className="sidebar-link-icon">
                {item.icon}
              </span>

              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <span>KIMBOLITO</span>
        <small>v1.0</small>
      </div>
    </aside>
  );
}