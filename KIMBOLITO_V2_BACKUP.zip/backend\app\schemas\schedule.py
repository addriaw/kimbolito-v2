from datetime import date, time, datetime

from pydantic import BaseModel, Field


class ScheduleBase(BaseModel):

    food_id: int

    grams: float = Field(
        gt=0,
        description="Cantidad de alimento en gramos.",
    )

    feeding_time: time

    monday: bool = False
    tuesday: bool = False
    wednesday: bool = False
    thursday: bool = False
    friday: bool = False
    saturday: bool = False
    sunday: bool = False

    start_date: date | None = None
    end_date: date | None = None

    active: bool = True


class ScheduleCreate(ScheduleBase):
    pass


class ScheduleResponse(ScheduleBase):

    id: int

    last_executed_at: datetime | None = None

    created_at: datetime

    model_config = {
        "from_attributes": True
    }