from datetime import datetime, timezone
from typing import Optional


ESP32_TIMEOUT_SECONDS = 30
SENSOR_TIMEOUT_SECONDS = 30
WHEEL_TIMEOUT_SECONDS = 30


class SystemStatusService:
    def __init__(self):
        self.last_esp32_heartbeat: Optional[datetime] = None
        self.last_sensor_update: Optional[datetime] = None
        self.last_wheel_update: Optional[datetime] = None

        self.mqtt_connected = False
        self.database_connected = False
        self.feeder_available = False

    # =====================================================
    # FECHA / HORA
    # =====================================================

    def _now(self) -> datetime:
        return datetime.now(timezone.utc)

    # =====================================================
    # MQTT
    # =====================================================

    def set_mqtt_connected(self, connected: bool):
        self.mqtt_connected = connected

    # =====================================================
    # BASE DE DATOS
    # =====================================================

    def set_database_connected(self, connected: bool):
        self.database_connected = connected

    # =====================================================
    # ALIMENTADOR
    # =====================================================

    def set_feeder_available(self, available: bool):
        self.feeder_available = available

    # =====================================================
    # HEARTBEAT ESP32
    # =====================================================

    def register_heartbeat(self):
        self.last_esp32_heartbeat = self._now()

        # Si el ESP32 está enviando heartbeat,
        # consideramos disponible el alimentador.
        self.feeder_available = True

    # =====================================================
    # SENSORES
    # =====================================================

    def register_sensor_update(self):
        self.last_sensor_update = self._now()

    # =====================================================
    # RUEDA
    # =====================================================

    def register_wheel_update(self):
        self.last_wheel_update = self._now()

    # =====================================================
    # VALIDAR TIEMPOS
    # =====================================================

    def _is_recent(
        self,
        timestamp: Optional[datetime],
        timeout: int,
    ) -> bool:

        if timestamp is None:
            return False

        elapsed = (
            self._now() - timestamp
        ).total_seconds()

        return elapsed <= timeout

    # =====================================================
    # ESTADO COMPLETO
    # =====================================================

    def get_status(self):

        esp32_online = self._is_recent(
            self.last_esp32_heartbeat,
            ESP32_TIMEOUT_SECONDS,
        )

        sensors_active = self._is_recent(
            self.last_sensor_update,
            SENSOR_TIMEOUT_SECONDS,
        )

        wheel_available = self._is_recent(
            self.last_wheel_update,
            WHEEL_TIMEOUT_SECONDS,
        )

        # Si el ESP32 dejó de responder,
        # el alimentador ya no debe considerarse disponible.
        feeder_available = (
            self.feeder_available
            and esp32_online
        )

        system_connected = (
            esp32_online
            and self.mqtt_connected
            and self.database_connected
        )

        return {
            "system_connected": system_connected,

            "esp32": {
                "connected": esp32_online,
                "last_seen": (
                    self.last_esp32_heartbeat.isoformat()
                    if self.last_esp32_heartbeat
                    else None
                ),
            },

            "mqtt": {
                "connected": self.mqtt_connected,
            },

            "database": {
                "connected": self.database_connected,
            },

            "sensors": {
                "active": sensors_active,
                "last_update": (
                    self.last_sensor_update.isoformat()
                    if self.last_sensor_update
                    else None
                ),
            },

            "feeder": {
                "available": feeder_available,
            },

            "wheel": {
                "available": wheel_available,
                "last_update": (
                    self.last_wheel_update.isoformat()
                    if self.last_wheel_update
                    else None
                ),
            },
        }


system_status = SystemStatusService()