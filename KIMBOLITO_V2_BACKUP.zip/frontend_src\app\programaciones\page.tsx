"use client";

import { useEffect, useState } from "react";

import {
  Food,
  Schedule,
  getFoods,
  getSchedules,
  createSchedule,
  toggleSchedule,
} from "@/lib/api";


type DayKey =
  | "monday"
  | "tuesday"
  | "wednesday"
  | "thursday"
  | "friday"
  | "saturday"
  | "sunday";


const DAYS: {
  key: DayKey;
  label: string;
  short: string;
}[] = [
  {
    key: "monday",
    label: "Lunes",
    short: "L",
  },
  {
    key: "tuesday",
    label: "Martes",
    short: "M",
  },
  {
    key: "wednesday",
    label: "Miércoles",
    short: "X",
  },
  {
    key: "thursday",
    label: "Jueves",
    short: "J",
  },
  {
    key: "friday",
    label: "Viernes",
    short: "V",
  },
  {
    key: "saturday",
    label: "Sábado",
    short: "S",
  },
  {
    key: "sunday",
    label: "Domingo",
    short: "D",
  },
];


const initialDays: Record<DayKey, boolean> = {
  monday: true,
  tuesday: true,
  wednesday: true,
  thursday: true,
  friday: true,
  saturday: true,
  sunday: true,
};


export default function ProgramacionesPage() {

  const [foods, setFoods] =
    useState<Food[]>([]);

  const [schedules, setSchedules] =
    useState<Schedule[]>([]);

  const [foodId, setFoodId] =
    useState<number | null>(null);

  const [grams, setGrams] =
    useState<number>(5);

  const [feedingTime, setFeedingTime] =
    useState("08:00");

  const [days, setDays] =
    useState<Record<DayKey, boolean>>(
      initialDays
    );

  const [startDate, setStartDate] =
    useState("");

  const [endDate, setEndDate] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [loadingSchedules, setLoadingSchedules] =
    useState(true);

  const [error, setError] =
    useState("");

  const [message, setMessage] =
    useState("");

  const [showForm, setShowForm] =
    useState(false);


  // =====================================================
  // CARGAR DATOS
  // =====================================================

  useEffect(() => {

    loadData();

  }, []);


  async function loadData() {

    try {

      setLoadingSchedules(true);
      setError("");

      const [
        foodsData,
        schedulesData,
      ] = await Promise.all([
        getFoods(),
        getSchedules(),
      ]);

      setFoods(foodsData);
      setSchedules(schedulesData);

      if (
        foodsData.length > 0 &&
        foodId === null
      ) {
        setFoodId(
          foodsData[0].id
        );
      }

    } catch (err) {

      setError(
        err instanceof Error
          ? err.message
          : "No se pudieron cargar las programaciones."
      );

    } finally {

      setLoadingSchedules(false);
    }
  }


  // =====================================================
  // CAMBIAR DÍA
  // =====================================================

  function toggleDay(
    day: DayKey
  ) {

    setDays(
      previous => ({
        ...previous,
        [day]: !previous[day],
      })
    );
  }


  // =====================================================
  // TODOS LOS DÍAS
  // =====================================================

  function selectAllDays() {

    setDays({
      monday: true,
      tuesday: true,
      wednesday: true,
      thursday: true,
      friday: true,
      saturday: true,
      sunday: true,
    });
  }


  // =====================================================
  // NINGÚN DÍA
  // =====================================================

  function clearDays() {

    setDays({
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false,
    });
  }


  // =====================================================
  // CREAR PROGRAMACIÓN
  // =====================================================

  async function handleCreateSchedule() {

    setError("");
    setMessage("");

    if (!foodId) {

      setError(
        "Selecciona un alimento."
      );

      return;
    }

    if (grams <= 0) {

      setError(
        "La cantidad debe ser mayor que 0 gramos."
      );

      return;
    }

    const selectedDays =
      Object.values(days)
        .some(value => value);

    if (!selectedDays) {

      setError(
        "Selecciona al menos un día."
      );

      return;
    }

    if (
      startDate &&
      endDate &&
      endDate < startDate
    ) {

      setError(
        "La fecha final no puede ser anterior a la fecha inicial."
      );

      return;
    }


    try {

      setLoading(true);

      const newSchedule =
        await createSchedule({

          food_id: foodId,

          grams,

          feeding_time: feedingTime,

          monday: days.monday,
          tuesday: days.tuesday,
          wednesday: days.wednesday,
          thursday: days.thursday,
          friday: days.friday,
          saturday: days.saturday,
          sunday: days.sunday,

          start_date:
            startDate || null,

          end_date:
            endDate || null,

          active: true,

        });


      setSchedules(
        previous => [
          newSchedule,
          ...previous,
        ]
      );


      setMessage(
        "Programación creada correctamente."
      );


      // -----------------------------------------------
      // RESTABLECER FORMULARIO
      // -----------------------------------------------

      setGrams(5);
      setFeedingTime("08:00");

      setDays(initialDays);

      setStartDate("");
      setEndDate("");

      setShowForm(false);


    } catch (err) {

      setError(
        err instanceof Error
          ? err.message
          : "No se pudo crear la programación."
      );

    } finally {

      setLoading(false);
    }
  }


  // =====================================================
  // ACTIVAR / DESACTIVAR
  // =====================================================

  async function handleToggle(
    scheduleId: number
  ) {

    try {

      setError("");

      const updated =
        await toggleSchedule(
          scheduleId
        );


      setSchedules(
        previous =>
          previous.map(schedule =>
            schedule.id === scheduleId
              ? updated
              : schedule
          )
      );


    } catch (err) {

      setError(
        err instanceof Error
          ? err.message
          : "No se pudo cambiar el estado."
      );
    }
  }


  // =====================================================
  // OBTENER NOMBRE DEL ALIMENTO
  // =====================================================

  function getFoodName(
    schedule: Schedule
  ) {

    const food =
      foods.find(
        item =>
          item.id === schedule.food_id
      );

    return (
      food?.name ||
      `Alimento #${schedule.food_id}`
    );
  }


  // =====================================================
  // DÍAS ACTIVOS
  // =====================================================

  function getActiveDays(
    schedule: Schedule
  ) {

    return DAYS
      .filter(
        day =>
          schedule[day.key]
      )
      .map(
        day => day.short
      )
      .join(" · ");
  }


  // =====================================================
  // RENDER
  // =====================================================

  return (

    <main className="schedules-page">

      {/* =================================================
          ENCABEZADO
      ================================================= */}

      <section className="schedules-header">

        <div>

          <span className="eyebrow">
            PROGRAMACIONES
          </span>

          <h1>
            Horarios de alimentación
          </h1>

          <p>
            Programa cuándo y cuánto alimento
            debe recibir el hamster.
          </p>

        </div>


        <button
          className="primary-button"
          onClick={() =>
            setShowForm(
              previous => !previous
            )
          }
        >
          {showForm
            ? "Cerrar"
            : "+ Nueva programación"}
        </button>

      </section>


      {/* =================================================
          MENSAJES
      ================================================= */}

      {message && (

        <div className="success-message">
          ✓ {message}
        </div>

      )}


      {error && (

        <div className="error-message">
          {error}
        </div>

      )}


      {/* =================================================
          FORMULARIO
      ================================================= */}

      {showForm && (

        <section className="schedule-form-card">

          <div className="section-title">

            <div>

              <span className="eyebrow">
                NUEVA PROGRAMACIÓN
              </span>

              <h2>
                Configurar alimentación
              </h2>

            </div>

          </div>


          <div className="form-grid">

            {/* ALIMENTO */}

            <div className="form-group">

              <label>
                Tipo de alimento
              </label>

              <select
                value={foodId ?? ""}
                onChange={event =>
                  setFoodId(
                    Number(
                      event.target.value
                    )
                  )
                }
              >

                {foods.length === 0 && (
                  <option value="">
                    No hay alimentos
                  </option>
                )}

                {foods.map(food => (

                  <option
                    key={food.id}
                    value={food.id}
                  >
                    {food.name}
                  </option>

                ))}

              </select>

            </div>


            {/* GRAMOS */}

            <div className="form-group">

              <label>
                Cantidad
              </label>

              <div className="input-with-unit">

                <input
                  type="number"
                  min="0.1"
                  step="0.1"
                  value={grams}
                  onChange={event =>
                    setGrams(
                      Number(
                        event.target.value
                      )
                    )
                  }
                />

                <span>
                  g
                </span>

              </div>

            </div>


            {/* HORA */}

            <div className="form-group">

              <label>
                Hora de alimentación
              </label>

              <input
                type="time"
                value={feedingTime}
                onChange={event =>
                  setFeedingTime(
                    event.target.value
                  )
                }
              />

            </div>


            {/* FECHA INICIO */}

            <div className="form-group">

              <label>
                Fecha de inicio
              </label>

              <input
                type="date"
                value={startDate}
                onChange={event =>
                  setStartDate(
                    event.target.value
                  )
                }
              />

            </div>


            {/* FECHA FINAL */}

            <div className="form-group">

              <label>
                Fecha de finalización
              </label>

              <input
                type="date"
                value={endDate}
                onChange={event =>
                  setEndDate(
                    event.target.value
                  )
                }
              />

            </div>

          </div>


          {/* =================================================
              DÍAS
          ================================================= */}

          <div className="days-section">

            <div className="days-header">

              <label>
                Días de alimentación
              </label>

              <div className="days-actions">

                <button
                  type="button"
                  onClick={selectAllDays}
                >
                  Todos
                </button>

                <button
                  type="button"
                  onClick={clearDays}
                >
                  Ninguno
                </button>

              </div>

            </div>


            <div className="days-grid">

              {DAYS.map(day => (

                <button
                  type="button"
                  key={day.key}
                  className={
                    days[day.key]
                      ? "day-button active"
                      : "day-button"
                  }
                  onClick={() =>
                    toggleDay(
                      day.key
                    )
                  }
                  title={day.label}
                >
                  {day.short}
                </button>

              ))}

            </div>

          </div>


          {/* =================================================
              ACCIONES
          ================================================= */}

          <div className="form-actions">

            <button
              className="secondary-button"
              onClick={() =>
                setShowForm(false)
              }
            >
              Cancelar
            </button>


            <button
              className="primary-button"
              onClick={
                handleCreateSchedule
              }
              disabled={loading}
            >
              {loading
                ? "Guardando..."
                : "Guardar programación"}
            </button>

          </div>

        </section>

      )}


      {/* =================================================
          PROGRAMACIONES
      ================================================= */}

      <section className="schedules-section">

        <div className="section-title">

          <div>

            <span className="eyebrow">
              MIS HORARIOS
            </span>

            <h2>
              Programaciones configuradas
            </h2>

          </div>

          <span className="schedule-count">
            {schedules.length}
            {" "}
            programación
            {schedules.length !== 1
              ? "es"
              : ""}
          </span>

        </div>


        {loadingSchedules ? (

          <div className="empty-state">
            <div className="loading-spinner" />
            <p>
              Cargando programaciones...
            </p>
          </div>

        ) : schedules.length === 0 ? (

          <div className="empty-state">

            <div className="empty-icon">
              ⏰
            </div>

            <h3>
              No hay programaciones
            </h3>

            <p>
              Crea tu primera programación
              para automatizar la alimentación.
            </p>

            <button
              className="primary-button"
              onClick={() =>
                setShowForm(true)
              }
            >
              Crear programación
            </button>

          </div>

        ) : (

          <div className="schedule-list">

            {schedules.map(schedule => (

              <article
                className="schedule-card"
                key={schedule.id}
              >

                {/* HORA */}

                <div className="schedule-time">

                  <span>
                    {schedule.feeding_time}
                  </span>

                </div>


                {/* INFORMACIÓN */}

                <div className="schedule-content">

                  <div className="schedule-main">

                    <h3>
                      {getFoodName(
                        schedule
                      )}
                    </h3>

                    <span>
                      {schedule.grams}
                      {" "}
                      gramos
                    </span>

                  </div>


                  <div className="schedule-details">

                    <span>
                      📅{" "}
                      {getActiveDays(
                        schedule
                      )}
                    </span>


                    {schedule.start_date && (

                      <span>
                        Desde{" "}
                        {schedule.start_date}
                      </span>

                    )}


                    {schedule.end_date && (

                      <span>
                        Hasta{" "}
                        {schedule.end_date}
                      </span>

                    )}

                  </div>

                </div>


                {/* ESTADO */}

                <div className="schedule-status">

                  <span
                    className={
                      schedule.active
                        ? "status active"
                        : "status inactive"
                    }
                  >
                    {schedule.active
                      ? "● Activa"
                      : "● Inactiva"}
                  </span>

                  <button
                    className="toggle-button"
                    onClick={() =>
                      handleToggle(
                        schedule.id
                      )
                    }
                  >
                    {schedule.active
                      ? "Desactivar"
                      : "Activar"}
                  </button>

                </div>

              </article>

            ))}

          </div>

        )}

      </section>

    </main>
  );
}