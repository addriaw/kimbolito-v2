from datetime import datetime, date
import threading
import time
from typing import Optional

from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.schedule import FeedingSchedule
from app.models.food import Food
from app.models.feeding import FeedingRecord

from app.services.feeding_service import calculate_duration
from app.services.mqtt_service import publish_feeding
from app.services.notification_service import (
    create_notification,
    build_monitoring_message,
)


# =========================================================
# CONFIGURACIÓN
# =========================================================

# El scheduler revisa las programaciones cada 30 segundos.
CHECK_INTERVAL_SECONDS = 30


# =========================================================
# CONTROL DEL SCHEDULER
# =========================================================

scheduler_thread: Optional[threading.Thread] = None
scheduler_running = False


# =========================================================
# EVITAR EJECUCIÓN DUPLICADA
# =========================================================

execution_lock = threading.Lock()


# =========================================================
# OBTENER DÍA ACTUAL
# =========================================================

def get_today_field() -> str:
    """
    Devuelve el nombre del campo correspondiente al día actual.
    """

    weekday = datetime.now().weekday()

    days = {
        0: "monday",
        1: "tuesday",
        2: "wednesday",
        3: "thursday",
        4: "friday",
        5: "saturday",
        6: "sunday",
    }

    return days[weekday]


# =========================================================
# VALIDAR FECHA Y DÍA
# =========================================================

def is_schedule_valid_today(
    schedule: FeedingSchedule,
    today: date,
) -> bool:
    """
    Comprueba:
    - fecha inicial
    - fecha final
    - día de la semana
    """

    if (
        schedule.start_date
        and today < schedule.start_date
    ):
        return False

    if (
        schedule.end_date
        and today > schedule.end_date
    ):
        return False

    today_field = get_today_field()

    return bool(
        getattr(
            schedule,
            today_field,
            False,
        )
    )


# =========================================================
# COMPROBAR SI YA FUE EJECUTADA
# =========================================================

def already_executed_today(
    schedule: FeedingSchedule,
) -> bool:
    """
    Evita ejecutar una programación más de una vez
    durante el mismo día.
    """

    if not schedule.last_executed_at:
        return False

    last_execution = schedule.last_executed_at

    return (
        last_execution.date()
        == datetime.now().date()
    )


# =========================================================
# GENERAR NOTIFICACIÓN DE ALIMENTACIÓN AUTOMÁTICA
# =========================================================

def notify_automatic_feeding(
    db: Session,
    feeding_id: Optional[int],
    grams: Optional[float],
    failed: bool = False,
):
    """
    Genera una notificación inmediata para una alimentación
    automática.

    No depende de notify_feeding_action().
    Utiliza directamente las funciones existentes del
    notification_service.py.
    """

    if failed:

        if feeding_id is not None:
            action = (
                "❌ Alimentación automática fallida "
                f"(#{feeding_id})."
            )
        else:
            action = (
                "❌ Alimentación automática fallida."
            )

        notification_type = "FEEDING_FAILED"
        severity = "ERROR"

    else:

        if feeding_id is not None:

            if grams is not None:
                action = (
                    "🍽️ Alimentación automática iniciada: "
                    f"{grams:.1f} g "
                    f"(#{feeding_id})."
                )
            else:
                action = (
                    "🍽️ Alimentación automática iniciada "
                    f"(#{feeding_id})."
                )

        else:
            action = (
                "🍽️ Alimentación automática iniciada."
            )

        notification_type = "FEEDING_STARTED"
        severity = "INFO"

    return create_notification(
        db=db,
        notification_type=notification_type,
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db=db,
            action=action,
        ),
        severity=severity,
    )


# =========================================================
# EJECUTAR PROGRAMACIÓN
# =========================================================

def execute_schedule(
    schedule: FeedingSchedule,
    db: Session,
):
    """
    Ejecuta una programación automática.

    Flujo:

    1. Buscar alimento.
    2. Validar flow_rate.
    3. Calcular duración.
    4. Crear historial.
    5. Enviar orden MQTT.
    6. Actualizar estado.
    7. Generar notificación.
    8. Marcar programación como ejecutada.
    """

    # -----------------------------------------------------
    # BUSCAR ALIMENTO
    # -----------------------------------------------------

    food = (
        db.query(Food)
        .filter(
            Food.id == schedule.food_id
        )
        .first()
    )

    if not food:

        print(
            f"[SCHEDULER] Alimento "
            f"{schedule.food_id} no encontrado."
        )

        return


    # -----------------------------------------------------
    # VALIDAR FLOW RATE
    # -----------------------------------------------------

    if (
        food.flow_rate is None
        or food.flow_rate <= 0
    ):

        print(
            f"[SCHEDULER] El alimento #{food.id} "
            "no tiene un flow_rate válido."
        )

        return


    # -----------------------------------------------------
    # VALIDAR GRAMOS
    # -----------------------------------------------------

    if (
        schedule.grams is None
        or schedule.grams <= 0
    ):

        print(
            f"[SCHEDULER] La programación "
            f"#{schedule.id} tiene una cantidad "
            "de gramos inválida."
        )

        return


    # -----------------------------------------------------
    # CALCULAR DURACIÓN
    # -----------------------------------------------------

    try:

        duration = calculate_duration(
            schedule.grams,
            food.flow_rate,
        )

    except Exception as error:

        print(
            "[SCHEDULER] Error calculando duración: "
            f"{error}"
        )

        return


    print(
        f"[SCHEDULER] Duración calculada: "
        f"{duration:.2f} segundos."
    )


    # -----------------------------------------------------
    # CREAR HISTÓRICO
    # -----------------------------------------------------

    record = FeedingRecord(
        food_id=food.id,
        grams=schedule.grams,
        duration_seconds=duration,
        feeding_type="SCHEDULED",
        status="PENDING",
    )

    db.add(record)
    db.commit()
    db.refresh(record)

    print(
        f"[SCHEDULER] Alimentación creada "
        f"#{record.id}"
    )


    # -----------------------------------------------------
    # ENVIAR MQTT
    # -----------------------------------------------------

    try:

        mqtt_sent = publish_feeding(
            feeding_id=record.id,
            duration_seconds=duration,
        )

    except Exception as error:

        mqtt_sent = False

        print(
            "[SCHEDULER] Error enviando MQTT: "
            f"{error}"
        )


    # -----------------------------------------------------
    # ALIMENTACIÓN ENVIADA CORRECTAMENTE
    # -----------------------------------------------------

    if mqtt_sent:

        record.status = "RUNNING"

        db.commit()
        db.refresh(record)

        print(
            f"[SCHEDULER] Orden enviada "
            f"para alimentación #{record.id}"
        )


        # -------------------------------------------------
        # NOTIFICACIÓN INMEDIATA
        # -------------------------------------------------

        try:

            notify_automatic_feeding(
                db=db,
                feeding_id=record.id,
                grams=record.grams,
                failed=False,
            )

            print(
                "[SCHEDULER] Notificación de "
                "alimentación automática generada."
            )

        except Exception as error:

            print(
                "[SCHEDULER] Error generando "
                f"notificación: {error}"
            )


    # -----------------------------------------------------
    # FALLÓ EL ENVÍO MQTT
    # -----------------------------------------------------

    else:

        record.status = "FAILED"

        db.commit()
        db.refresh(record)

        print(
            f"[SCHEDULER] Error enviando "
            f"alimentación #{record.id}"
        )


        # -------------------------------------------------
        # NOTIFICACIÓN DE ERROR
        # -------------------------------------------------

        try:

            notify_automatic_feeding(
                db=db,
                feeding_id=record.id,
                grams=record.grams,
                failed=True,
            )

            print(
                "[SCHEDULER] Notificación de "
                "alimentación fallida generada."
            )

        except Exception as error:

            print(
                "[SCHEDULER] Error generando "
                f"notificación de fallo: {error}"
            )


    # -----------------------------------------------------
    # ACTUALIZAR PROGRAMACIÓN
    # -----------------------------------------------------

    schedule.last_executed_at = datetime.now()

    db.commit()


# =========================================================
# COMPROBAR PROGRAMACIONES
# =========================================================

def check_schedules():
    """
    Busca todas las programaciones activas y ejecuta
    las correspondientes al día y minuto actuales.
    """

    db = SessionLocal()

    try:

        schedules = (
            db.query(
                FeedingSchedule
            )
            .filter(
                FeedingSchedule.active == True
            )
            .all()
        )


        now = datetime.now()

        today = now.date()

        current_time = now.time()


        for schedule in schedules:

            # ---------------------------------------------
            # VALIDAR FECHA Y DÍA
            # ---------------------------------------------

            if not is_schedule_valid_today(
                schedule,
                today,
            ):
                continue


            # ---------------------------------------------
            # EVITAR DUPLICADOS
            # ---------------------------------------------

            if already_executed_today(
                schedule
            ):
                continue


            # ---------------------------------------------
            # VALIDAR HORA
            # ---------------------------------------------

            scheduled_time = (
                schedule.feeding_time
            )

            if scheduled_time is None:

                print(
                    f"[SCHEDULER] Programación "
                    f"#{schedule.id} no tiene "
                    "feeding_time."
                )

                continue


            current_minutes = (
                current_time.hour * 60
                + current_time.minute
            )


            scheduled_minutes = (
                scheduled_time.hour * 60
                + scheduled_time.minute
            )


            # Solo se compara hora y minuto.
            if (
                current_minutes
                != scheduled_minutes
            ):
                continue


            # ---------------------------------------------
            # BLOQUEAR EJECUCIÓN
            # ---------------------------------------------

            if not execution_lock.acquire(
                blocking=False
            ):
                continue


            try:

                print("")
                print(
                    "=================================="
                )

                print(
                    "🐹 EJECUTANDO PROGRAMACIÓN"
                )

                print(
                    "=================================="
                )


                print(
                    f"Programación: "
                    f"#{schedule.id}"
                )


                print(
                    f"Alimento: "
                    f"{schedule.food_id}"
                )


                print(
                    f"Cantidad: "
                    f"{schedule.grams} g"
                )


                print(
                    f"Hora: "
                    f"{schedule.feeding_time}"
                )


                execute_schedule(
                    schedule,
                    db,
                )


                print(
                    "=================================="
                )


            except Exception as error:

                print(
                    "[SCHEDULER] Error ejecutando "
                    f"programación #{schedule.id}: "
                    f"{error}"
                )


            finally:

                execution_lock.release()


    except Exception as error:

        print(
            f"[SCHEDULER] Error: {error}"
        )


    finally:

        db.close()


# =========================================================
# LOOP PRINCIPAL
# =========================================================

def scheduler_loop():
    """
    Loop permanente del scheduler.
    """

    global scheduler_running

    print(
        "[SCHEDULER] Loop iniciado."
    )


    while scheduler_running:

        try:

            check_schedules()

        except Exception as error:

            print(
                "[SCHEDULER] Error en loop: "
                f"{error}"
            )


        time.sleep(
            CHECK_INTERVAL_SECONDS
        )


    print(
        "[SCHEDULER] Loop detenido."
    )


# =========================================================
# INICIAR
# =========================================================

def start_scheduler():
    """
    Inicia el scheduler en segundo plano.
    """

    global scheduler_thread
    global scheduler_running


    if scheduler_running:

        print(
            "[SCHEDULER] Ya está ejecutándose."
        )

        return


    scheduler_running = True


    scheduler_thread = threading.Thread(
        target=scheduler_loop,
        daemon=True,
        name="HamsterScheduler",
    )


    scheduler_thread.start()


    print(
        "[SCHEDULER] Scheduler iniciado."
    )


# =========================================================
# DETENER
# =========================================================

def stop_scheduler():
    """
    Detiene el scheduler.
    """

    global scheduler_running
    global scheduler_thread


    scheduler_running = False


    if scheduler_thread:

        scheduler_thread.join(
            timeout=2
        )

        scheduler_thread = None


    print(
        "[SCHEDULER] Scheduler detenido."
    )