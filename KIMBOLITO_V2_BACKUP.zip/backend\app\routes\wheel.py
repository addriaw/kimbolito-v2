from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import desc
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.wheel_activity import WheelActivity


router = APIRouter(
    prefix="/api/wheel",
    tags=["Wheel Activity"],
)


@router.get("/latest")
def get_latest_wheel_activity(
    db: Session = Depends(get_db),
):
    activity = (
        db.query(WheelActivity)
        .order_by(desc(WheelActivity.created_at))
        .first()
    )

    if not activity:
        raise HTTPException(
            status_code=404,
            detail="No hay datos de actividad de la rueda.",
        )

    return {
        "id": activity.id,
        "device": activity.device,
        "session_id": activity.session_id,
        "revolutions_total": activity.revolutions_total,
        "distance_cm_total": activity.distance_cm_total,
        "distance_m_total": round(
            activity.distance_cm_total / 100,
            2,
        ),
        "speed_cm_s": activity.speed_cm_s,
        "active_seconds_total": activity.active_seconds_total,
        "movement_detected": activity.movement_detected,
        "created_at": activity.created_at,
    }


@router.get("/history")
def get_wheel_history(
    hours: int = Query(
        default=24,
        ge=1,
        le=720,
    ),
    limit: int = Query(
        default=500,
        ge=1,
        le=5000,
    ),
    db: Session = Depends(get_db),
):
    since = datetime.utcnow() - timedelta(hours=hours)

    records = (
        db.query(WheelActivity)
        .filter(
            WheelActivity.created_at >= since
        )
        .order_by(desc(WheelActivity.created_at))
        .limit(limit)
        .all()
    )

    return [
        {
            "id": item.id,
            "device": item.device,
            "session_id": item.session_id,
            "revolutions_total": item.revolutions_total,
            "distance_cm_total": item.distance_cm_total,
            "distance_m_total": round(
                item.distance_cm_total / 100,
                2,
            ),
            "speed_cm_s": item.speed_cm_s,
            "active_seconds_total": item.active_seconds_total,
            "movement_detected": item.movement_detected,
            "created_at": item.created_at,
        }
        for item in records
    ]


@router.get("/today")
def get_today_activity(
    db: Session = Depends(get_db),
):
    start = datetime.utcnow().replace(
        hour=0,
        minute=0,
        second=0,
        microsecond=0,
    )

    records = (
        db.query(WheelActivity)
        .filter(
            WheelActivity.created_at >= start
        )
        .order_by(WheelActivity.created_at.asc())
        .all()
    )

    if not records:
        return {
            "date": start.date(),
            "revolutions": 0,
            "distance_m": 0,
            "active_minutes": 0,
            "max_speed_cm_s": 0,
            "samples": 0,
        }

    sessions = {}

    for record in records:
        session_key = (
            record.session_id
            or f"{record.device}-default"
        )

        sessions.setdefault(
            session_key,
            [],
        ).append(record)

    total_revolutions = 0
    total_distance_cm = 0.0
    total_active_seconds = 0.0
    max_speed = 0.0

    for session_records in sessions.values():
        first = session_records[0]
        last = session_records[-1]

        revolutions = max(
            last.revolutions_total - first.revolutions_total,
            0,
        )

        distance_cm = max(
            last.distance_cm_total - first.distance_cm_total,
            0.0,
        )

        active_seconds = max(
            last.active_seconds_total
            - first.active_seconds_total,
            0.0,
        )

        total_revolutions += revolutions
        total_distance_cm += distance_cm
        total_active_seconds += active_seconds

        for item in session_records:
            max_speed = max(
                max_speed,
                item.speed_cm_s,
            )

    return {
        "date": start.date(),
        "revolutions": total_revolutions,
        "distance_m": round(
            total_distance_cm / 100,
            2,
        ),
        "active_minutes": round(
            total_active_seconds / 60,
            2,
        ),
        "max_speed_cm_s": round(
            max_speed,
            2,
        ),
        "samples": len(records),
    }