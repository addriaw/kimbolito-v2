from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.sensor import SensorData
from app.schemas.sensor import (
    SensorCreate,
    SensorResponse,
)


router = APIRouter(
    prefix="/api/sensors",
    tags=["Sensores"],
)


# =========================================================
# REGISTRAR LECTURA
# =========================================================

@router.post(
    "",
    response_model=SensorResponse,
)
def create_sensor_data(
    request: SensorCreate,
    db: Session = Depends(get_db),
):

    sensor = SensorData(

        temperatura=request.temperatura,

        humedad=request.humedad,

        luz_encendida=request.luz_encendida,
    )

    db.add(sensor)

    db.commit()

    db.refresh(sensor)

    return sensor


# =========================================================
# ÚLTIMA LECTURA
# =========================================================

@router.get(
    "/latest",
    response_model=SensorResponse | None,
)
def get_latest_sensor(
    db: Session = Depends(get_db),
):

    return (
        db.query(SensorData)
        .order_by(
            SensorData.fecha_registro.desc()
        )
        .first()
    )


# =========================================================
# HISTÓRICO DE SENSORES
# =========================================================

@router.get(
    "",
    response_model=list[SensorResponse],
)
def get_sensor_history(
    limit: int = Query(
        default=100,
        ge=1,
        le=1000,
    ),

    db: Session = Depends(get_db),
):

    return (
        db.query(SensorData)
        .order_by(
            SensorData.fecha_registro.desc()
        )
        .limit(limit)
        .all()
    )