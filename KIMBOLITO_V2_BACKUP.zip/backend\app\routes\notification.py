from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import desc
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.notification import Notification


router = APIRouter(
    prefix="/api/notifications",
    tags=["Notifications"],
)


@router.get("/")
def get_notifications(
    limit: int = 50,
    db: Session = Depends(get_db),
):
    limit = min(max(limit, 1), 200)

    notifications = (
        db.query(Notification)
        .order_by(desc(Notification.created_at))
        .limit(limit)
        .all()
    )

    return [
        {
            "id": item.id,
            "type": item.type,
            "title": item.title,
            "message": item.message,
            "severity": item.severity,
            "is_read": item.is_read,
            "created_at": item.created_at,
        }
        for item in notifications
    ]


@router.get("/unread-count")
def get_unread_count(
    db: Session = Depends(get_db),
):
    count = (
        db.query(Notification)
        .filter(
            Notification.is_read.is_(False)
        )
        .count()
    )

    return {
        "count": count,
    }


@router.patch("/{notification_id}/read")
def mark_notification_read(
    notification_id: int,
    db: Session = Depends(get_db),
):
    notification = (
        db.query(Notification)
        .filter(Notification.id == notification_id)
        .first()
    )

    if not notification:
        raise HTTPException(
            status_code=404,
            detail="Notificación no encontrada.",
        )

    notification.is_read = True

    db.commit()
    db.refresh(notification)

    return {
        "id": notification.id,
        "is_read": notification.is_read,
    }


@router.patch("/read-all")
def mark_all_notifications_read(
    db: Session = Depends(get_db),
):
    db.query(Notification).filter(
        Notification.is_read.is_(False)
    ).update(
        {
            Notification.is_read: True,
        },
        synchronize_session=False,
    )

    db.commit()

    return {
        "message": "Todas las notificaciones fueron marcadas como leídas.",
    }