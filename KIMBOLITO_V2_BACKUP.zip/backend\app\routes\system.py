from fastapi import APIRouter

from app.services.system_status_service import (
    system_status,
)


router = APIRouter(
    prefix="/api/system",
    tags=["System"],
)


@router.get("/status")
def get_system_status():

    return system_status.get_status()