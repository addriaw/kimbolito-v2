from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class FoodBase(BaseModel):
    name: str = Field(
        min_length=2,
        max_length=100
    )

    flow_rate: float = Field(
        gt=0,
        description="Gramos de alimento dispensados por segundo"
    )

    description: str | None = Field(
        default=None,
        max_length=255
    )


class FoodCreate(FoodBase):
    pass


class FoodUpdate(BaseModel):
    name: str | None = Field(
        default=None,
        min_length=2,
        max_length=100
    )

    flow_rate: float | None = Field(
        default=None,
        gt=0
    )

    description: str | None = Field(
        default=None,
        max_length=255
    )

    active: bool | None = None


class FoodResponse(FoodBase):
    id: int
    active: bool
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(
        from_attributes=True
    )