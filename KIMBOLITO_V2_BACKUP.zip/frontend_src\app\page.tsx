import {
  Clock3,
  Droplets,
  Lightbulb,
  Thermometer,
  Utensils,
  FlaskConical,
  Wifi,
  ChevronRight,
} from "lucide-react";

export default function Home() {
  return (
    <div className="dashboard-content">

      {/* Bienvenida */}
      <section className="welcome-section">
        <div>
          <span className="section-label">
            SISTEMA DE MONITOREO
          </span>

          <h1>
            Buenas tardes 👋
          </h1>

          <p>
            Controla la alimentación y monitorea el
            ambiente de tu hamster desde un solo lugar.
          </p>
        </div>

        <div className="connection-badge">
          <span className="status-dot" />
          Sistema conectado
        </div>
      </section>

      {/* Sensores */}
      <section className="sensor-grid">

        {/* Temperatura */}
        <div className="sensor-card">
          <div className="sensor-card-header">
            <div className="sensor-icon temperature">
              <Thermometer size={21} />
            </div>

            <span>Temperatura</span>
          </div>

          <div className="sensor-value">
            26.4
            <small>°C</small>
          </div>

          <div className="sensor-footer">
            <span>Rango normal</span>
            <span className="normal-text">
              18°C — 35°C
            </span>
          </div>
        </div>

        {/* Humedad */}
        <div className="sensor-card">
          <div className="sensor-card-header">
            <div className="sensor-icon humidity">
              <Droplets size={21} />
            </div>

            <span>Humedad</span>
          </div>

          <div className="sensor-value">
            63
            <small>%</small>
          </div>

          <div className="sensor-footer">
            <span>Rango normal</span>
            <span className="normal-text">
              40% — 80%
            </span>
          </div>
        </div>

        {/* Iluminación */}
        <div className="sensor-card">
          <div className="sensor-card-header">
            <div className="sensor-icon light">
              <Lightbulb size={21} />
            </div>

            <span>Iluminación</span>
          </div>

          <div className="sensor-value sensor-text">
            Oscuro
          </div>

          <div className="sensor-footer">
            <span>LED</span>
            <span className="normal-text">
              Encendido
            </span>
          </div>
        </div>

        {/* ESP32 */}
        <div className="sensor-card">
          <div className="sensor-card-header">
            <div className="sensor-icon connection">
              <Wifi size={21} />
            </div>

            <span>Dispositivo</span>
          </div>

          <div className="sensor-value sensor-text">
            Online
          </div>

          <div className="sensor-footer">
            <span>ESP32</span>
            <span className="normal-text">
              Wi-Fi
            </span>
          </div>
        </div>

      </section>

      {/* Alimentación */}
      <section className="main-grid">

        {/* Próxima alimentación */}
        <div className="feeding-card">

          <div className="card-heading">
            <div>
              <span className="section-label">
                ALIMENTACIÓN
              </span>

              <h2>
                Próxima alimentación
              </h2>
            </div>

            <div className="feeding-icon">
              <Utensils size={22} />
            </div>
          </div>

          <div className="next-feeding">

            <div className="feeding-time">
              <Clock3 size={20} />
              <strong>20:00</strong>
            </div>

            <div className="feeding-info">
              <div>
                <span>Alimento</span>
                <strong>Pienso</strong>
              </div>

              <div>
                <span>Cantidad</span>
                <strong>5.0 g</strong>
              </div>

              <div>
                <span>Tiempo estimado</span>
                <strong>1.79 s</strong>
              </div>
            </div>

          </div>

          <div className="feeding-actions">

            <button className="primary-button">
              <Utensils size={19} />
              Dar comida ahora
            </button>

            <button className="secondary-button">
              <FlaskConical size={19} />
              Prueba
            </button>

          </div>

        </div>

        {/* Última alimentación */}
        <div className="last-feeding-card">

          <div className="card-heading">
            <div>
              <span className="section-label">
                REGISTRO
              </span>

              <h2>
                Última alimentación
              </h2>
            </div>
          </div>

          <div className="last-feeding">

            <div className="last-feeding-icon">
              <Utensils size={20} />
            </div>

            <div className="last-feeding-info">
              <strong>Pienso</strong>

              <span>
                Hoy a las 14:00
              </span>
            </div>

            <div className="last-feeding-quantity">
              <strong>5.0 g</strong>
              <span>Automática</span>
            </div>

          </div>

          <button className="history-link">
            Ver histórico
            <ChevronRight size={17} />
          </button>

        </div>

      </section>

      {/* Estado */}
      <section className="system-status">

        <div className="system-status-header">
          <div>
            <span className="section-label">
              ESTADO DEL SISTEMA
            </span>

            <h2>
              Todo funciona correctamente
            </h2>
          </div>

          <div className="system-online">
            <span className="status-dot" />
            Operativo
          </div>
        </div>

        <div className="system-components">

          <div>
            <span className="status-check">✓</span>
            <span>DHT22</span>
          </div>

          <div>
            <span className="status-check">✓</span>
            <span>LDR</span>
          </div>

          <div>
            <span className="status-check">✓</span>
            <span>Servo</span>
          </div>

          <div>
            <span className="status-check">✓</span>
            <span>LED</span>
          </div>

          <div>
            <span className="status-check">✓</span>
            <span>MQTT</span>
          </div>

        </div>

      </section>

    </div>
  );
}