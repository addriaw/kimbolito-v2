import json
import os
from urllib.parse import urlparse

from pywebpush import WebPushException, webpush
from sqlalchemy.orm import Session

from app.models.push_subscription import PushSubscription


# ============================================================
# CONFIGURACIÓN VAPID
# ============================================================

VAPID_PRIVATE_KEY = os.path.join(
    os.path.dirname(
        os.path.dirname(
            os.path.dirname(
                os.path.abspath(__file__)
            )
        )
    ),
    "vapid_private.pem",
)

VAPID_SUBJECT = "mailto:hamsteriot@example.com"


# ============================================================
# OBTENER AUDIENCE DEL ENDPOINT PUSH
# ============================================================

def get_vapid_audience(endpoint: str) -> str:
    """
    Obtiene el audience requerido por VAPID.

    Ejemplo:

    Endpoint:
    https://fcm.googleapis.com/fcm/send/xxxxx

    Resultado:
    https://fcm.googleapis.com
    """

    parsed_url = urlparse(endpoint)

    if not parsed_url.scheme or not parsed_url.netloc:
        raise ValueError(
            "El endpoint Push no tiene una URL válida."
        )

    audience = f"{parsed_url.scheme}://{parsed_url.netloc}"

    return audience


# ============================================================
# ENVIAR UNA NOTIFICACIÓN
# ============================================================

def send_push(
    subscription: PushSubscription,
    payload: dict,
) -> str:

    subscription_info = {
        "endpoint": subscription.endpoint,
        "keys": {
            "p256dh": subscription.p256dh,
            "auth": subscription.auth,
        },
    }

    try:

        # ----------------------------------------------------
        # AUDIENCE
        # ----------------------------------------------------

        audience = get_vapid_audience(
            subscription.endpoint
        )

        # ----------------------------------------------------
        # ENVIAR PUSH
        # ----------------------------------------------------

        webpush(
            subscription_info=subscription_info,
            data=json.dumps(
                payload,
                ensure_ascii=False,
            ),
            vapid_private_key=VAPID_PRIVATE_KEY,
            vapid_claims={
                "sub": VAPID_SUBJECT,
                "aud": audience,
            },
            ttl=300,
        )

        print("")
        print("[PUSH] Notificación enviada:")
        print(
            f"       Endpoint: "
            f"{subscription.endpoint[:60]}..."
        )
        print(
            f"       Audience: {audience}"
        )
        print("")

        return "success"

    except WebPushException as error:

        status_code = getattr(
            error,
            "status_code",
            None,
        )

        print("")
        print("[PUSH] Error enviando:")
        print(f"       Status: {status_code}")
        print(f"       Error: {error}")
        print("")

        # ----------------------------------------------------
        # SUSCRIPCIÓN REALMENTE INVÁLIDA
        # ----------------------------------------------------
        # 404 / 410 normalmente indican que el endpoint
        # ya no existe o la suscripción expiró.
        # ----------------------------------------------------

        if status_code in (404, 410):
            return "invalid"

        # ----------------------------------------------------
        # OTRO ERROR
        # ----------------------------------------------------
        # No eliminamos la suscripción porque puede ser un
        # problema temporal o de configuración.
        # ----------------------------------------------------

        return "error"

    except Exception as error:

        print("")
        print("[PUSH] Error inesperado:")
        print(f"       {error}")
        print("")

        return "error"


# ============================================================
# ENVIAR A TODAS LAS SUSCRIPCIONES
# ============================================================

def send_push_to_all(
    db: Session,
    title: str,
    message: str,
    notification_type: str,
    severity: str,
):

    subscriptions = (
        db.query(PushSubscription)
        .all()
    )

    # --------------------------------------------------------
    # SIN SUSCRIPCIONES
    # --------------------------------------------------------

    if not subscriptions:

        print("")
        print(
            "[PUSH] No existen suscripciones."
        )
        print("")

        return

    # --------------------------------------------------------
    # PAYLOAD
    # --------------------------------------------------------

    payload = {
        "title": title,
        "message": message,
        "type": notification_type,
        "severity": severity,
    }

    invalid_subscriptions = []

    # --------------------------------------------------------
    # ENVIAR
    # --------------------------------------------------------

    for subscription in subscriptions:

        result = send_push(
            subscription,
            payload,
        )

        if result == "invalid":

            invalid_subscriptions.append(
                subscription
            )

    # --------------------------------------------------------
    # ELIMINAR SOLAMENTE SUSCRIPCIONES
    # REALMENTE INVÁLIDAS
    # --------------------------------------------------------

    for subscription in invalid_subscriptions:

        print("")
        print(
            "[PUSH] Eliminando suscripción "
            "realmente inválida."
        )
        print(
            f"       ID: {subscription.id}"
        )
        print("")

        db.delete(subscription)

    if invalid_subscriptions:
        db.commit()