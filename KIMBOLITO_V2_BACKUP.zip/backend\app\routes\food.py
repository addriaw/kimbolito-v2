from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.food import Food
from app.schemas.food import (
    FoodCreate,
    FoodResponse,
    FoodUpdate,
)


router = APIRouter(
    prefix="/api/foods",
    tags=["Alimentos"],
)


@router.post(
    "",
    response_model=FoodResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_food(
    food: FoodCreate,
    db: Session = Depends(get_db),
):
    existing_food = (
        db.query(Food)
        .filter(Food.name == food.name)
        .first()
    )

    if existing_food:
        raise HTTPException(
            status_code=400,
            detail="Ya existe un alimento con ese nombre.",
        )

    new_food = Food(
        name=food.name,
        flow_rate=food.flow_rate,
        description=food.description,
    )

    db.add(new_food)
    db.commit()
    db.refresh(new_food)

    return new_food


@router.get(
    "",
    response_model=list[FoodResponse],
)
def get_foods(
    db: Session = Depends(get_db),
):
    return (
        db.query(Food)
        .order_by(Food.name.asc())
        .all()
    )


@router.get(
    "/{food_id}",
    response_model=FoodResponse,
)
def get_food(
    food_id: int,
    db: Session = Depends(get_db),
):
    food = (
        db.query(Food)
        .filter(Food.id == food_id)
        .first()
    )

    if not food:
        raise HTTPException(
            status_code=404,
            detail="Alimento no encontrado.",
        )

    return food


@router.put(
    "/{food_id}",
    response_model=FoodResponse,
)
def update_food(
    food_id: int,
    food_data: FoodUpdate,
    db: Session = Depends(get_db),
):
    food = (
        db.query(Food)
        .filter(Food.id == food_id)
        .first()
    )

    if not food:
        raise HTTPException(
            status_code=404,
            detail="Alimento no encontrado.",
        )

    update_data = food_data.model_dump(
        exclude_unset=True
    )

    for key, value in update_data.items():
        setattr(food, key, value)

    db.commit()
    db.refresh(food)

    return food


@router.delete(
    "/{food_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_food(
    food_id: int,
    db: Session = Depends(get_db),
):
    food = (
        db.query(Food)
        .filter(Food.id == food_id)
        .first()
    )

    if not food:
        raise HTTPException(
            status_code=404,
            detail="Alimento no encontrado.",
        )

    db.delete(food)
    db.commit()

    return None