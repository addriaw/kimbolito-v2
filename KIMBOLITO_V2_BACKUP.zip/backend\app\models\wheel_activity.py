from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class WheelActivity(Base):
    __tablename__ = "wheel_activity"

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True,
    )

    device: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="ESP32",
    )

    session_id: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        index=True,
    )

    revolutions_total: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
    )

    distance_cm_total: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        default=0.0,
    )

    speed_cm_s: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        default=0.0,
    )

    active_seconds_total: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        default=0.0,
    )

    movement_detected: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=datetime.utcnow,
        nullable=False,
    )