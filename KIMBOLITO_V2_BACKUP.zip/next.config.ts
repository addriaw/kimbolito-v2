import withSerwistInit from "@serwist/next";

const withSerwist = withSerwistInit({
  swSrc: "src/app/sw.ts",
  swDest: "public/sw.js",
});

const nextConfig = {
  reactCompiler: true,

  allowedDevOrigins: [
    "192.168.1.34",
  ],
};

export default withSerwist(nextConfig);