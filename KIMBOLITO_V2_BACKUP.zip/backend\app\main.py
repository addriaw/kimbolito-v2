from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import (
    Base,
    engine,
)

from app.services.system_status_service import (
    system_status,
)


# =========================================================
# MODELOS
# =========================================================

from app.models import (
    sensor as sensor_model,
    food as food_model,
    feeding as feeding_model,
    schedule as schedule_model,
    hardware_event as hardware_event_model,
    wheel_activity as wheel_activity_model,
    notification as notification_model,
    push_subscription as push_subscription_model,
)


# =========================================================
# ROUTERS
# =========================================================

from app.routes import (
    sensor,
    food,
    feeding,
    schedule,
    whatsapp,
    wheel,
    notification,
    system,
    push,
)


# =========================================================
# SERVICIOS
# =========================================================

from app.services.scheduler_service import (
    start_scheduler,
    stop_scheduler,
)

from app.services.mqtt_service import (
    connect_mqtt,
)


# =========================================================
# BASE DE DATOS
# =========================================================

print(
    "[DATABASE] Verificando conexión..."
)

try:

    Base.metadata.create_all(
        bind=engine
    )

    system_status.set_database_connected(
        True
    )

    print(
        "[DATABASE] Base de datos "
        "conectada correctamente."
    )

except Exception as error:

    system_status.set_database_connected(
        False
    )

    print(
        "[DATABASE] Error de conexión: "
        f"{error}"
    )


# =========================================================
# LIFESPAN
# =========================================================

@asynccontextmanager
async def lifespan(app: FastAPI):

    print("")
    print(
        "=========================================="
    )
    print(
        "🐹 KIMBOLITO - INICIANDO SISTEMA"
    )
    print(
        "=========================================="
    )

    # -----------------------------------------------------
    # MQTT
    # -----------------------------------------------------

    print(
        "[MQTT] Iniciando conexión..."
    )

    mqtt_connected = connect_mqtt()

    if mqtt_connected:

        print(
            "[MQTT] Cliente MQTT iniciado."
        )

    else:

        print(
            "[MQTT] No se pudo iniciar "
            "la conexión con el broker."
        )

        print(
            "[MQTT] El sistema continuará "
            "funcionando."
        )

    # -----------------------------------------------------
    # SCHEDULER
    # -----------------------------------------------------

    print(
        "[SCHEDULER] Iniciando scheduler..."
    )

    start_scheduler()

    print(
        "[SCHEDULER] Scheduler iniciado "
        "correctamente."
    )

    # -----------------------------------------------------
    # ESTADO INICIAL
    # -----------------------------------------------------

    status = (
        system_status.get_status()
    )

    print("")
    print(
        "[SYSTEM] Estado inicial:"
    )

    print(
        "         MQTT: "
        f"{status['mqtt']['connected']}"
    )

    print(
        "         Database: "
        f"{status['database']['connected']}"
    )

    print(
        "         ESP32: "
        f"{status['esp32']['connected']}"
    )

    print(
        "         Sensors: "
        f"{status['sensors']['active']}"
    )

    print(
        "         Wheel: "
        f"{status['wheel']['available']}"
    )

    print("")

    print(
        "=========================================="
    )

    print(
        "✅ KIMBOLITO LISTO"
    )

    print(
        "=========================================="
    )

    print("")

    yield

    # =====================================================
    # APAGADO
    # =====================================================

    print("")

    print(
        "=========================================="
    )

    print(
        "🛑 DETENIENDO KIMBOLITO"
    )

    print(
        "=========================================="
    )

    # -----------------------------------------------------
    # SCHEDULER
    # -----------------------------------------------------

    stop_scheduler()

    print(
        "[SCHEDULER] Scheduler detenido."
    )

    print(
        "=========================================="
    )

    print(
        "✅ SISTEMA DETENIDO"
    )

    print(
        "=========================================="
    )

    print("")


# =========================================================
# FASTAPI
# =========================================================

app = FastAPI(

    title="Hamster IoT API",

    description=(
        "API V2 para monitoreo ambiental, "
        "actividad física, alimentación automática, "
        "programaciones, estado del sistema "
        "y notificaciones de Hamster IoT."
    ),

    version="2.0.0",

    lifespan=lifespan,
)


# =========================================================
# CORS
# =========================================================

app.add_middleware(

    CORSMiddleware,

    allow_origins=[
        "http://localhost:3000",
        "http://:192.168.1.34",
    ],

    allow_origin_regex=(
        r"^https?://192\.168\.\d+\.\d+:3000$"
    ),

    allow_credentials=True,

    allow_methods=[
        "*"
    ],

    allow_headers=[
        "*"
    ],
)


# =========================================================
# ROOT
# =========================================================

@app.get("/")
def root():

    return {

        "application":
            "Hamster IoT",

        "version":
            "2.0.0",

        "status":
            "online",

        "message": (
            "Backend V2 funcionando "
            "correctamente."
        ),
    }


# =========================================================
# HEALTH CHECK
# =========================================================

@app.get("/health")
def health():

    status = (
        system_status.get_status()
    )

    return {

        "status":
            "healthy",

        "application":
            "Hamster IoT",

        "version":
            "2.0.0",

        "system_connected":
            status["system_connected"],
    }


# =========================================================
# ROUTES — SENSORES
# =========================================================

app.include_router(
    sensor.router
)


# =========================================================
# ROUTES — ALIMENTOS
# =========================================================

app.include_router(
    food.router
)


# =========================================================
# ROUTES — ALIMENTACIÓN
# =========================================================

app.include_router(
    feeding.router
)


# =========================================================
# ROUTES — PROGRAMACIONES
# =========================================================

app.include_router(
    schedule.router
)


# =========================================================
# ROUTES — WHATSAPP
# =========================================================

app.include_router(
    whatsapp.router
)


# =========================================================
# ROUTES — RUEDA
# =========================================================

app.include_router(
    wheel.router
)


# =========================================================
# ROUTES — NOTIFICACIONES
# =========================================================

app.include_router(
    notification.router
)


# =========================================================
# ROUTES — SISTEMA
# =========================================================

app.include_router(
    system.router
)


# =========================================================
# ROUTES — PUSH NOTIFICATIONS
# =========================================================

app.include_router(
    push.router
)