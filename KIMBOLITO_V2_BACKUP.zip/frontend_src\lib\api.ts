const API_URL =
  process.env.NEXT_PUBLIC_API_URL ||
  "http://192.168.1.34:8000";

// =====================================================
// TIPOS
// =====================================================

export interface Food {
  id: number;
  name: string;
  flow_rate: number;
  description?: string | null;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface FeedingCalculation {
  food_id: number;
  grams: number;
  flow_rate: number;
  duration_seconds: number;
}

export interface FeedingRecord {
  id: number;
  food_id: number;
  food_name: string;
  grams: number;
  duration_seconds: number;
  feeding_type: string;
  status: string;
  created_at: string;
}

export interface Consumption {
  total_grams: number;
  total_feedings: number;
}

export interface Schedule {
  id: number;
  food_id: number;
  grams: number;
  feeding_time: string;

  monday: boolean;
  tuesday: boolean;
  wednesday: boolean;
  thursday: boolean;
  friday: boolean;
  saturday: boolean;
  sunday: boolean;

  start_date?: string | null;
  end_date?: string | null;

  active: boolean;

  last_executed_at?: string | null;

  created_at: string;
}

export interface SensorData {
  id: number;
  temperatura: number;
  humedad: number;
  luz_encendida: boolean;
  fecha_registro: string;
}

export interface WhatsAppResponse {
  feeding_id: number;
  message: string;
  whatsapp_url: string;
}

// =====================================================
// RUEDA — TIPOS V2
// =====================================================

export interface WheelActivity {
  id: number;
  device: string;
  session_id?: string | null;

  revolutions_total: number;
  distance_cm_total: number;
  distance_m_total: number;

  speed_cm_s: number;

  active_seconds_total: number;

  movement_detected: boolean;

  created_at: string;
}

export interface WheelToday {
  date: string;

  revolutions: number;

  distance_m: number;

  active_minutes: number;

  max_speed_cm_s: number;

  samples: number;
}

// =====================================================
// NOTIFICACIONES — TIPOS V2
// =====================================================

export type NotificationSeverity =
  | "INFO"
  | "SUCCESS"
  | "WARNING"
  | "ERROR";

export interface Notification {
  id: number;

  type: string;

  title: string;

  message: string;

  severity: NotificationSeverity;

  is_read: boolean;

  created_at: string;
}

export interface NotificationUnreadCount {
  count: number;
}


// =====================================================
// FUNCIÓN BASE
// =====================================================

async function request<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {

  const url = `${API_URL}${endpoint}`;

  console.log("[API] Solicitando:", url);

  const response = await fetch(
    url,
    {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(options?.headers || {}),
      },
      cache: "no-store",
    }
  );

  console.log(
    "[API] Respuesta:",
    response.status,
    response.statusText,
    endpoint
  );

  // =====================================================
  // ERROR HTTP
  // =====================================================

  if (!response.ok) {

    const text = await response.text();

    console.error(
      "[API] Error:",
      response.status,
      text
    );

    let message = `Error HTTP ${response.status}`;

    if (text) {
      try {
        const data = JSON.parse(text);

        if (data?.detail) {
          message = data.detail;
        }
      } catch {
        // La respuesta no era JSON
        message = text;
      }
    }

    throw new Error(message);
  }

  // =====================================================
  // SIN CONTENIDO
  // =====================================================

  if (response.status === 204) {
    return undefined as T;
  }

  // =====================================================
  // LEER RESPUESTA
  // =====================================================

  const text = await response.text();

  // Evitar:
  // SyntaxError: Unexpected end of JSON input

  if (!text || !text.trim()) {
    console.warn(
      "[API] Respuesta vacía:",
      endpoint
    );

    return undefined as T;
  }

  // =====================================================
  // CONVERTIR JSON
  // =====================================================

  try {

    return JSON.parse(text) as T;

  } catch (error) {

    console.error(
      "[API] Respuesta no válida:",
      endpoint
    );

    console.error(
      "[API] Contenido recibido:",
      text
    );

    throw new Error(
      `La API devolvió una respuesta inválida en ${endpoint}`
    );
  }
}


// =====================================================
// ALIMENTOS
// =====================================================

export async function getFoods(): Promise<Food[]> {

  return request<Food[]>(
    "/api/foods"
  );
}


// =====================================================
// CALCULAR ALIMENTACIÓN
// =====================================================

export async function calculateFeeding(
  foodId: number,
  grams: number
): Promise<FeedingCalculation> {

  return request<FeedingCalculation>(
    "/api/feeding/calculate",
    {
      method: "POST",

      body: JSON.stringify({
        food_id: foodId,
        grams,
      }),
    }
  );
}


// =====================================================
// DAR COMIDA AHORA
// =====================================================

export async function feedNow(
  foodId: number,
  grams: number
): Promise<FeedingRecord> {

  return request<FeedingRecord>(
    "/api/feeding/manual",
    {
      method: "POST",

      body: JSON.stringify({
        food_id: foodId,
        grams,
      }),
    }
  );
}


// =====================================================
// PRUEBA
// =====================================================

export async function testFeeding(
  foodId: number,
  grams: number
): Promise<FeedingRecord> {

  return request<FeedingRecord>(
    "/api/feeding/test",
    {
      method: "POST",

      body: JSON.stringify({
        food_id: foodId,
        grams,
      }),
    }
  );
}


// =====================================================
// HISTÓRICO ALIMENTACIÓN
// =====================================================

export async function getFeedingHistory(
  limit = 100
): Promise<FeedingRecord[]> {

  return request<FeedingRecord[]>(
    `/api/feeding/history?limit=${limit}`
  );
}


// =====================================================
// CONSUMO
// =====================================================

export async function getConsumption(): Promise<Consumption> {

  return request<Consumption>(
    "/api/feeding/consumption"
  );
}


// =====================================================
// OBTENER ALIMENTACIÓN POR ID
// =====================================================

export async function getFeeding(
  id: number
): Promise<FeedingRecord> {

  return request<FeedingRecord>(
    `/api/feeding/history/${id}`
  );
}


// =====================================================
// PROGRAMACIONES
// =====================================================

export async function getSchedules(): Promise<Schedule[]> {

  return request<Schedule[]>(
    "/api/schedules"
  );
}


// =====================================================
// CREAR PROGRAMACIÓN
// =====================================================

export async function createSchedule(
  schedule: Omit<
    Schedule,
    "id" |
    "created_at" |
    "last_executed_at"
  >
): Promise<Schedule> {

  return request<Schedule>(
    "/api/schedules",
    {
      method: "POST",

      body: JSON.stringify(
        schedule
      ),
    }
  );
}


// =====================================================
// OBTENER PROGRAMACIÓN
// =====================================================

export async function getSchedule(
  id: number
): Promise<Schedule> {

  return request<Schedule>(
    `/api/schedules/${id}`
  );
}


// =====================================================
// ACTIVAR / DESACTIVAR
// =====================================================

export async function toggleSchedule(
  id: number
): Promise<Schedule> {

  return request<Schedule>(
    `/api/schedules/${id}/toggle`,
    {
      method: "PATCH",
    }
  );
}


// =====================================================
// SENSORES — ÚLTIMA LECTURA
// =====================================================

export async function getLatestSensor():
  Promise<SensorData | null> {

  return request<SensorData | null>(
    "/api/sensors/latest"
  );
}


// =====================================================
// SENSORES — HISTÓRICO
// =====================================================

export async function getSensorHistory(
  limit = 100
): Promise<SensorData[]> {

  return request<SensorData[]>(
    `/api/sensors?limit=${limit}`
  );
}


// =====================================================
// RUEDA — ÚLTIMA ACTIVIDAD
// =====================================================

export async function getLatestWheelActivity():
  Promise<WheelActivity> {

  return request<WheelActivity>(
    "/api/wheel/latest"
  );
}


// =====================================================
// RUEDA — HISTÓRICO
// =====================================================

export async function getWheelHistory(
  hours = 24,
  limit = 500
): Promise<WheelActivity[]> {

  return request<WheelActivity[]>(
    `/api/wheel/history?hours=${hours}&limit=${limit}`
  );
}


// =====================================================
// RUEDA — ACTIVIDAD DEL DÍA
// =====================================================

export async function getWheelToday():
  Promise<WheelToday> {

  return request<WheelToday>(
    "/api/wheel/today"
  );
}


// =====================================================
// NOTIFICACIONES
// =====================================================

export async function getNotifications(
  limit = 50
): Promise<Notification[]> {

  return request<Notification[]>(
    `/api/notifications/?limit=${limit}`
  );
}


// =====================================================
// NOTIFICACIONES — NO LEÍDAS
// =====================================================

export async function getUnreadNotificationCount():
  Promise<NotificationUnreadCount> {

  return request<NotificationUnreadCount>(
    "/api/notifications/unread-count"
  );
}


// =====================================================
// MARCAR NOTIFICACIÓN COMO LEÍDA
// =====================================================

export async function markNotificationAsRead(
  notificationId: number
) {

  return request<{
    id: number;
    is_read: boolean;
  }>(
    `/api/notifications/${notificationId}/read`,
    {
      method: "PATCH",
    }
  );
}


// =====================================================
// MARCAR TODAS COMO LEÍDAS
// =====================================================

export async function markAllNotificationsAsRead() {

  return request<{
    message: string;
  }>(
    "/api/notifications/read-all",
    {
      method: "PATCH",
    }
  );
}


// =====================================================
// WHATSAPP
// =====================================================

export function openWhatsApp(
  message: string
): void {

  const phoneNumber = "";

  const encodedMessage =
    encodeURIComponent(message);

  const url = phoneNumber
    ? `https://wa.me/${phoneNumber}?text=${encodedMessage}`
    : `https://wa.me/?text=${encodedMessage}`;

  window.open(
    url,
    "_blank",
    "noopener,noreferrer"
  );
}


// =====================================================
// WHATSAPP - HISTÓRICO
// =====================================================

export async function getWhatsAppFeeding(
  feedingId: number
): Promise<WhatsAppResponse> {

  return request<WhatsAppResponse>(
    `/api/whatsapp/feeding/${feedingId}`
  );
}


// =====================================================
// WEB PUSH
// =====================================================

export interface PushSubscriptionResponse {
  status: "created" | "updated";
  id: number;
}

export interface PushStatus {
  subscriptions: number;
}


// =====================================================
// OBTENER CLAVE PÚBLICA VAPID
// =====================================================

export async function getPushPublicKey(): Promise<string> {
  const response = await request<{
    public_key: string;
  }>(
    "/api/push/public-key"
  );

  return response.public_key;
}


// =====================================================
// REGISTRAR SUSCRIPCIÓN PUSH
// =====================================================

export async function subscribeToPush(
  subscription: PushSubscription
): Promise<PushSubscriptionResponse> {

  const json = subscription.toJSON();

  if (
    !json.endpoint ||
    !json.keys?.p256dh ||
    !json.keys?.auth
  ) {
    throw new Error(
      "La suscripción Push no contiene todos los datos necesarios."
    );
  }

  return request<PushSubscriptionResponse>(
    "/api/push/subscribe",
    {
      method: "POST",

      body: JSON.stringify({
        endpoint: json.endpoint,

        keys: {
          p256dh: json.keys.p256dh,

          auth: json.keys.auth,
        },
      }),
    }
  );
}


// =====================================================
// ESTADO DE SUSCRIPCIONES
// =====================================================

export async function getPushStatus(): Promise<PushStatus> {
  return request<PushStatus>(
    "/api/push/status"
  );
}