from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
import base64

from cryptography.hazmat.primitives import serialization

from app.database import get_db
from app.models.push_subscription import PushSubscription


router = APIRouter(
    prefix="/api/push",
    tags=["Push Notifications"]
)


# ============================================================
# ESQUEMAS
# ============================================================

class PushKeys(BaseModel):
    p256dh: str
    auth: str


class PushSubscriptionRequest(BaseModel):
    endpoint: str
    keys: PushKeys


# ============================================================
# OBTENER CLAVE PÚBLICA VAPID
# ============================================================

@router.get("/public-key")
def get_public_key():
    try:
        with open("vapid_public.pem", "rb") as file:
            public_key = serialization.load_pem_public_key(
                file.read()
            )

        public_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint,
        )

        public_key_base64 = (
            base64.urlsafe_b64encode(public_bytes)
            .rstrip(b"=")
            .decode("utf-8")
        )

        return {
            "public_key": public_key_base64
        }

    except FileNotFoundError:
        raise HTTPException(
            status_code=500,
            detail="No existe la clave pública VAPID."
        )

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Error obteniendo la clave pública VAPID: {error}"
        )


# ============================================================
# REGISTRAR SUSCRIPCIÓN
# ============================================================

@router.post("/subscribe")
def subscribe(
    subscription: PushSubscriptionRequest,
    db: Session = Depends(get_db),
):
    endpoint = subscription.endpoint
    p256dh = subscription.keys.p256dh
    auth = subscription.keys.auth

    # --------------------------------------------------------
    # VALIDACIONES
    # --------------------------------------------------------

    if not endpoint:
        raise HTTPException(
            status_code=400,
            detail="El endpoint Push está vacío."
        )

    if not p256dh:
        raise HTTPException(
            status_code=400,
            detail="La clave p256dh está vacía."
        )

    if not auth:
        raise HTTPException(
            status_code=400,
            detail="La clave auth está vacía."
        )

    # --------------------------------------------------------
    # BUSCAR SUSCRIPCIÓN EXISTENTE
    # --------------------------------------------------------

    existing = (
        db.query(PushSubscription)
        .filter(
            PushSubscription.endpoint == endpoint
        )
        .first()
    )

    # --------------------------------------------------------
    # ACTUALIZAR
    # --------------------------------------------------------

    if existing:
        existing.p256dh = p256dh
        existing.auth = auth

        db.commit()
        db.refresh(existing)

        print("")
        print("==========================================")
        print("[PUSH] Suscripción actualizada.")
        print(f"[PUSH] ID: {existing.id}")
        print("==========================================")
        print("")

        return {
            "status": "updated",
            "id": existing.id
        }

    # --------------------------------------------------------
    # CREAR
    # --------------------------------------------------------

    new_subscription = PushSubscription(
        endpoint=endpoint,
        p256dh=p256dh,
        auth=auth,
    )

    db.add(new_subscription)
    db.commit()
    db.refresh(new_subscription)

    print("")
    print("==========================================")
    print("[PUSH] Nueva suscripción registrada.")
    print(f"[PUSH] ID: {new_subscription.id}")
    print("==========================================")
    print("")

    return {
        "status": "created",
        "id": new_subscription.id
    }


# ============================================================
# ESTADO PUSH
# ============================================================

@router.get("/status")
def push_status(
    db: Session = Depends(get_db)
):
    count = (
        db.query(PushSubscription)
        .count()
    )

    return {
        "subscriptions": count
    }

# ============================================================
# PRUEBA DE NOTIFICACIÓN PUSH
# ============================================================

from app.services.push_service import send_push_to_all


@router.post("/test")
def test_push(
    db: Session = Depends(get_db)
):
    subscriptions = (
        db.query(PushSubscription)
        .count()
    )

    if subscriptions == 0:
        raise HTTPException(
            status_code=400,
            detail="No existen suscripciones Push registradas."
        )

    send_push_to_all(
        db=db,
        title="🐹 KIMBOLITO",
        message="¡Las notificaciones Push están funcionando correctamente!",
        notification_type="TEST",
        severity="SUCCESS",
    )

    return {
        "status": "success",
        "message": "Notificación Push enviada.",
        "subscriptions": subscriptions,
    }