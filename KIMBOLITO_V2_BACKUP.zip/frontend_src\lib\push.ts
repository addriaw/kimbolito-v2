import {
  getPushPublicKey,
  subscribeToPush,
} from "@/lib/api";


// =====================================================
// CONVERTIR BASE64 URL-SAFE A ARRAYBUFFER
// =====================================================

function urlBase64ToArrayBuffer(
  base64String: string
): ArrayBuffer {

  const padding =
    "=".repeat(
      (4 - (base64String.length % 4)) % 4
    );

  const base64 =
    (
      base64String + padding
    )
      .replace(/-/g, "+")
      .replace(/_/g, "/");

  const rawData =
    window.atob(base64);

  const outputArray =
    new Uint8Array(
      rawData.length
    );

  for (
    let i = 0;
    i < rawData.length;
    i++
  ) {

    outputArray[i] =
      rawData.charCodeAt(i);
  }

  return outputArray.buffer;
}


// =====================================================
// VERIFICAR SOPORTE
// =====================================================

export function isPushSupported(): boolean {

  return (
    typeof window !== "undefined" &&
    "serviceWorker" in navigator &&
    "PushManager" in window &&
    "Notification" in window
  );
}


// =====================================================
// ACTIVAR NOTIFICACIONES
// =====================================================

export async function enablePushNotifications(): Promise<{
  success: boolean;
  message: string;
}> {

  // ---------------------------------------------------
  // VERIFICAR SOPORTE
  // ---------------------------------------------------

  if (!isPushSupported()) {

    return {
      success: false,
      message:
        "Este navegador no soporta notificaciones Push.",
    };
  }


  // ---------------------------------------------------
  // PEDIR PERMISO
  // ---------------------------------------------------

  const permission =
    await Notification.requestPermission();


  if (permission !== "granted") {

    return {
      success: false,
      message:
        "El permiso para las notificaciones fue rechazado.",
    };
  }


  // ---------------------------------------------------
  // ESPERAR SERVICE WORKER
  // ---------------------------------------------------

  const registration =
    await navigator.serviceWorker.ready;


  // ---------------------------------------------------
  // OBTENER CLAVE PÚBLICA VAPID
  // ---------------------------------------------------

  const publicKey =
    await getPushPublicKey();


  // ---------------------------------------------------
  // BUSCAR SUSCRIPCIÓN EXISTENTE
  // ---------------------------------------------------

  let subscription =
    await registration.pushManager
      .getSubscription();


  // ---------------------------------------------------
  // CREAR NUEVA SUSCRIPCIÓN
  // ---------------------------------------------------

  if (!subscription) {

    const applicationServerKey =
      urlBase64ToArrayBuffer(
        publicKey
      );

    subscription =
      await registration.pushManager.subscribe({

        userVisibleOnly: true,

        applicationServerKey,
      });
  }


  // ---------------------------------------------------
  // REGISTRAR SUSCRIPCIÓN EN FASTAPI
  // ---------------------------------------------------

  await subscribeToPush(
    subscription
  );


  // ---------------------------------------------------
  // RESPUESTA
  // ---------------------------------------------------

  return {

    success: true,

    message:
      "Notificaciones activadas correctamente.",
  };
}