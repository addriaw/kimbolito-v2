import json
from datetime import datetime, timezone
from typing import Optional

import paho.mqtt.client as mqtt

from app.database import SessionLocal
from app.models.sensor import SensorData
from app.models.hardware_event import HardwareEvent
from app.models.wheel_activity import WheelActivity

from app.services.system_status_service import system_status

from app.services.notification_service import (
    notify_feeding_success,
    notify_feeding_failed,
    notify_temperature_alert,
    notify_temperature_normal,
    notify_humidity_alert,
    notify_humidity_normal,
    notify_light_on,
    notify_light_off,
    notify_wheel_started,
    notify_wheel_finished,
    notify_esp32_online,
)


# =========================================================
# CONFIGURACIÓN MQTT
# =========================================================

# IMPORTANTE:
# Usamos IPv4 explícitamente para evitar diferencias entre
# localhost / 127.0.0.1 en Windows.
MQTT_BROKER = "192.168.1.34"
MQTT_PORT = 1883

MQTT_FEED_TOPIC = "hamster/feeding/command"
MQTT_STATUS_TOPIC = "hamster/feeding/status"
MQTT_SENSOR_TOPIC = "hamster/sensors/state"
MQTT_HARDWARE_TOPIC = "hamster/hardware/event"
MQTT_HEARTBEAT_TOPIC = "hamster/system/heartbeat"
MQTT_WHEEL_TOPIC = "hamster/wheel/state"


# =========================================================
# RANGOS
# =========================================================

TEMP_MIN = 18.0
TEMP_MAX = 35.0

HUM_MIN = 40.0
HUM_MAX = 80.0


# =========================================================
# ALERTAS
# =========================================================

temperature_alert_active = False
humidity_alert_active = False

ALERT_COOLDOWN_SECONDS = 15

last_temperature_alert_at: Optional[datetime] = None
last_humidity_alert_at: Optional[datetime] = None

last_light_state: Optional[bool] = None

wheel_activity_active = False

esp32_online_notified = False

# =========================================================
# CLIENTE MQTT
# =========================================================

client = mqtt.Client(
    callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
    client_id="hamster-fastapi"
)


# =========================================================
# CONEXIÓN MQTT
# =========================================================

def connect_mqtt():
    try:

        client.on_connect = on_connect
        client.on_disconnect = on_disconnect
        client.on_message = on_message

        print(
            f"[MQTT] Conectando a "
            f"{MQTT_BROKER}:{MQTT_PORT}"
        )

        client.connect(
            MQTT_BROKER,
            MQTT_PORT,
            60,
        )

        client.loop_start()

        print(
            "[MQTT] Loop MQTT iniciado."
        )

        return True

    except Exception as error:

        system_status.set_mqtt_connected(
            False
        )

        print(
            "[MQTT] ERROR DE CONEXIÓN:"
        )

        print(
            f"        {error}"
        )

        return False


# =========================================================
# CONEXIÓN EXITOSA
# =========================================================

def on_connect(
    client,
    userdata,
    flags,
    reason_code,
    properties,
):

    print()
    print(
        "=========================================="
    )

    print(
        "[MQTT] CALLBACK on_connect"
    )

    print(
        f"[MQTT] reason_code: {reason_code}"
    )

    print(
        f"[MQTT] broker: {MQTT_BROKER}:{MQTT_PORT}"
    )

    print(
        "=========================================="
    )


    if reason_code == 0:

        system_status.set_mqtt_connected(
            True
        )

        print(
            "[MQTT] ✅ Conectado correctamente."
        )


        # -------------------------------------------------
        # TOPICS
        # -------------------------------------------------

        topics = [
            MQTT_SENSOR_TOPIC,
            MQTT_HARDWARE_TOPIC,
            MQTT_STATUS_TOPIC,
            MQTT_WHEEL_TOPIC,
            MQTT_HEARTBEAT_TOPIC,
        ]


        # -------------------------------------------------
        # SUSCRIBIR
        # -------------------------------------------------

        for topic in topics:

            result, mid = client.subscribe(
                topic,
                qos=1,
            )

            if result == mqtt.MQTT_ERR_SUCCESS:

                print(
                    f"[MQTT] ✅ Suscrito a: {topic}"
                )

            else:

                print(
                    f"[MQTT] ❌ Error suscribiendo: {topic}"
                )

    else:

        system_status.set_mqtt_connected(
            False
        )

        print(
            "[MQTT] ❌ Error de conexión."
        )


# =========================================================
# DESCONEXIÓN
# =========================================================

def on_disconnect(
    client,
    userdata,
    disconnect_flags,
    reason_code,
    properties,
):

    system_status.set_mqtt_connected(
        False
    )

    print()

    print(
        "[MQTT] ⚠ Broker desconectado."
    )

    print(
        f"[MQTT] Código: {reason_code}"
    )


# =========================================================
# MENSAJES MQTT
# =========================================================

def on_message(
    client,
    userdata,
    message,
):

    try:

        topic = message.topic

        payload = message.payload.decode(
            "utf-8"
        )

        print()
        print(
            "=========================================="
        )

        print(
            "[MQTT] 📩 MENSAJE RECIBIDO"
        )

        print(
            f"[MQTT] Topic: {topic}"
        )

        print(
            f"[MQTT] Payload: {payload}"
        )

        print(
            "=========================================="
        )


        # -------------------------------------------------
        # SENSORES
        # -------------------------------------------------

        if topic == MQTT_SENSOR_TOPIC:

            process_sensor_message(
                payload
            )


        # -------------------------------------------------
        # HARDWARE
        # -------------------------------------------------

        elif topic == MQTT_HARDWARE_TOPIC:

            process_hardware_event(
                payload
            )


        # -------------------------------------------------
        # ALIMENTACIÓN
        # -------------------------------------------------

        elif topic == MQTT_STATUS_TOPIC:

            process_feeding_status(
                payload
            )


        # -------------------------------------------------
        # RUEDA
        # -------------------------------------------------

        elif topic == MQTT_WHEEL_TOPIC:

            process_wheel_message(
                payload
            )


        # -------------------------------------------------
        # HEARTBEAT
        # -------------------------------------------------

        elif topic == MQTT_HEARTBEAT_TOPIC:

            process_heartbeat(
                payload
            )

        else:

            print(
                f"[MQTT] Topic no reconocido: {topic}"
            )


    except Exception as error:

        print(
            "[MQTT] ❌ Error procesando mensaje:"
        )

        print(
            f"        {error}"
        )


# =========================================================
# HEARTBEAT ESP32
# =========================================================

def process_heartbeat(
    payload: str,
):
    global esp32_online_notified

    try:

        data = json.loads(
            payload
        )

        system_status.register_heartbeat()

        device = data.get(
            "device",
            "ESP32",
        )

        ip = data.get(
            "ip",
            "desconocida",
        )

        uptime = data.get(
            "uptime_seconds",
            0,
        )

        print(
            "[SYSTEM] ✅ Heartbeat ESP32 recibido."
        )

        print(
            f"         Device: {device}"
        )

        print(
            f"         IP: {ip}"
        )

        print(
            f"         Uptime: {uptime} s"
        )

        # =====================================================
        # NOTIFICAR SOLO LA PRIMERA VEZ
        # =====================================================

        if not esp32_online_notified:

            db = SessionLocal()

            try:

                notify_esp32_online(
                    db
                )

                esp32_online_notified = True

                print(
                    "[SYSTEM] 🔔 Notificación ESP32 online generada."
                )

            except Exception as error:

                print(
                    "[SYSTEM] Error generando "
                    "notificación ESP32:"
                )

                print(
                    f"          {error}"
                )

            finally:

                db.close()

        else:

            print(
                "[SYSTEM] ESP32 ya estaba marcado como online. "
                "No se genera nueva notificación."
            )

    except json.JSONDecodeError:

        print(
            "[SYSTEM] ❌ Heartbeat inválido."
        )

    except Exception as error:

        print(
            "[SYSTEM] ❌ Error heartbeat:"
        )

        print(
            f"          {error}"
        )

# =========================================================
# PROCESAR SENSORES
# =========================================================

def process_sensor_message(
    payload: str,
):

    global temperature_alert_active
    global humidity_alert_active
    global last_temperature_alert_at
    global last_humidity_alert_at
    global last_light_state


    db = SessionLocal()


    try:

        data = json.loads(
            payload
        )


        temperatura = data.get(
            "temperatura"
        )

        humedad = data.get(
            "humedad"
        )

        luz_encendida = data.get(
            "luz_encendida",
            False,
        )


        # -------------------------------------------------
        # VALIDACIÓN
        # -------------------------------------------------

        if temperatura is None:

            print(
                "[MQTT] ❌ Falta temperatura."
            )

            return


        if humedad is None:

            print(
                "[MQTT] ❌ Falta humedad."
            )

            return


        # -------------------------------------------------
        # TIPOS
        # -------------------------------------------------

        temperatura = float(
            temperatura
        )

        humedad = float(
            humedad
        )

        luz_encendida = bool(
            luz_encendida
        )


        # -------------------------------------------------
        # REGISTRAR ACTIVIDAD
        # -------------------------------------------------

        system_status.register_sensor_update()


        # -------------------------------------------------
        # GUARDAR
        # -------------------------------------------------

        sensor = SensorData(
            temperatura=temperatura,
            humedad=humedad,
            luz_encendida=luz_encendida,
        )


        db.add(
            sensor
        )

        db.commit()

        db.refresh(
            sensor
        )


        print(
            "[MQTT] ✅ Sensores guardados."
        )

        print(
            f"       Temperatura: "
            f"{sensor.temperatura:.1f} °C"
        )

        print(
            f"       Humedad: "
            f"{sensor.humedad:.1f} %"
        )

        print(
            f"       Luz: "
            f"{sensor.luz_encendida}"
        )


        # =================================================
        # TEMPERATURA
        # =================================================

        temperature_out_of_range = (
            temperatura < TEMP_MIN
            or temperatura > TEMP_MAX
        )


        if temperature_out_of_range:

            now = datetime.now(
                timezone.utc
            )


            should_notify_temperature = (
                not temperature_alert_active
                or last_temperature_alert_at is None
                or (
                    now
                    -
                    last_temperature_alert_at
                ).total_seconds()
                >= ALERT_COOLDOWN_SECONDS
            )


            temperature_alert_active = True


            if should_notify_temperature:

                notify_temperature_alert(
                    db,
                    temperatura,
                )

                last_temperature_alert_at = now

                print(
                    "[ALERT] ⚠ Temperatura fuera "
                    "de rango."
                )

            else:

                print(
                    "[ALERT] Temperatura fuera de "
                    "rango. Cooldown activo."
                )


        elif (
            not temperature_out_of_range
            and temperature_alert_active
        ):

            temperature_alert_active = False

            last_temperature_alert_at = None


            notify_temperature_normal(
                db,
                temperatura,
            )


            print(
                "[ALERT] ✅ Temperatura normalizada."
            )


        # =================================================
        # HUMEDAD
        # =================================================

        humidity_out_of_range = (
            humedad < HUM_MIN
            or humedad > HUM_MAX
        )


        if humidity_out_of_range:

            now = datetime.now(
                timezone.utc
            )


            should_notify_humidity = (
                not humidity_alert_active
                or last_humidity_alert_at is None
                or (
                    now
                    -
                    last_humidity_alert_at
                ).total_seconds()
                >= ALERT_COOLDOWN_SECONDS
            )


            humidity_alert_active = True


            if should_notify_humidity:

                notify_humidity_alert(
                    db,
                    humedad,
                )

                last_humidity_alert_at = now


                print(
                    "[ALERT] ⚠ Humedad fuera "
                    "de rango."
                )

            else:

                print(
                    "[ALERT] Humedad fuera de "
                    "rango. Cooldown activo."
                )


        elif (
            not humidity_out_of_range
            and humidity_alert_active
        ):

            humidity_alert_active = False

            last_humidity_alert_at = None


            notify_humidity_normal(
                db,
                humedad,
            )


            print(
                "[ALERT] ✅ Humedad normalizada."
            )


        # =================================================
        # LUZ
        # =================================================

        if last_light_state is None:

            last_light_state = (
                luz_encendida
            )

            print(
                "[LIGHT] Estado inicial registrado:"
                f" {luz_encendida}"
            )


        elif (
            luz_encendida
            != last_light_state
        ):

            if luz_encendida:

                notify_light_on(
                    db
                )

                print(
                    "[LIGHT] 💡 Luz encendida."
                )

            else:

                notify_light_off(
                    db
                )

                print(
                    "[LIGHT] 💡 Luz apagada."
                )


            last_light_state = (
                luz_encendida
            )


    except json.JSONDecodeError:

        print(
            "[MQTT] ❌ JSON de sensores inválido."
        )

        db.rollback()


    except Exception as error:

        db.rollback()

        print(
            "[MQTT] ❌ Error guardando sensores:"
        )

        print(
            f"        {error}"
        )


    finally:

        db.close()


# =========================================================
# PROCESAR HARDWARE
# =========================================================

def process_hardware_event(
    payload: str,
):

    db = SessionLocal()


    try:

        data = json.loads(
            payload
        )


        evento = data.get(
            "evento",
            data.get(
                "event",
                "Evento desconocido",
            ),
        )


        temperatura = data.get(
            "temperatura"
        )

        humedad = data.get(
            "humedad"
        )

        luz = data.get(
            "luz_encendida"
        )


        detalles = {
            "temperatura": temperatura,
            "humedad": humedad,
            "luz_encendida": luz,
        }


        hardware_event = HardwareEvent(
            device="ESP32",
            action=str(
                evento
            ),
            status="INFO",
            details=json.dumps(
                detalles,
                ensure_ascii=False,
            ),
        )


        db.add(
            hardware_event
        )

        db.commit()

        db.refresh(
            hardware_event
        )


        print(
            "[MQTT] ✅ Evento hardware guardado."
        )

        print(
            f"       Evento: {evento}"
        )


    except json.JSONDecodeError:

        print(
            "[MQTT] ❌ JSON hardware inválido."
        )

        db.rollback()


    except Exception as error:

        db.rollback()

        print(
            "[MQTT] ❌ Error hardware:"
        )

        print(
            f"        {error}"
        )


    finally:

        db.close()


# =========================================================
# PROCESAR RUEDA
# =========================================================

def process_wheel_message(
    payload: str,
):

    global wheel_activity_active


    db = SessionLocal()


    try:

        data = json.loads(
            payload
        )


        device = data.get(
            "device",
            "ESP32",
        )


        session_id = data.get(
            "session_id"
        )


        revolutions_total = int(
            data.get(
                "revoluciones_total",
                data.get(
                    "vueltas",
                    0,
                ),
            )
        )


        distance_cm_total = float(
            data.get(
                "distancia_total_cm",
                data.get(
                    "distancia_cm",
                    0,
                ),
            )
        )


        speed_cm_s = float(
            data.get(
                "velocidad_cm_s",
                data.get(
                    "velocidad",
                    0,
                ),
            )
        )


        active_seconds_total = float(
            data.get(
                "actividad_total_segundos",
                data.get(
                    "actividad_segundos",
                    0,
                ),
            )
        )


        movement_detected = bool(
            data.get(
                "movimiento",
                speed_cm_s > 0,
            )
        )


        # -------------------------------------------------
        # REGISTRAR ACTIVIDAD
        # -------------------------------------------------

        system_status.register_wheel_update()


        # -------------------------------------------------
        # GUARDAR
        # -------------------------------------------------

        wheel = WheelActivity(
            device=device,
            session_id=session_id,
            revolutions_total=revolutions_total,
            distance_cm_total=distance_cm_total,
            speed_cm_s=speed_cm_s,
            active_seconds_total=active_seconds_total,
            movement_detected=movement_detected,
        )


        db.add(
            wheel
        )

        db.commit()

        db.refresh(
            wheel
        )


        print(
            "[MQTT] ✅ Actividad de rueda guardada."
        )

        print(
            f"       Vueltas: "
            f"{wheel.revolutions_total}"
        )

        print(
            f"       Distancia: "
            f"{wheel.distance_cm_total / 100:.2f} m"
        )

        print(
            f"       Velocidad: "
            f"{wheel.speed_cm_s:.2f} cm/s"
        )

        print(
            f"       Actividad: "
            f"{wheel.active_seconds_total:.1f} s"
        )


        # =================================================
        # RUEDA INACTIVA → ACTIVA
        # =================================================

        if (
            movement_detected
            and not wheel_activity_active
        ):

            wheel_activity_active = True


            notify_wheel_started(
                db
            )


            print(
                "[WHEEL] 🐹 Actividad iniciada."
            )


        # =================================================
        # RUEDA ACTIVA → INACTIVA
        # =================================================

        elif (
            not movement_detected
            and wheel_activity_active
        ):

            wheel_activity_active = False


            distance_m = (
                distance_cm_total
                /
                100
            )


            notify_wheel_finished(
                db,
                revolutions_total,
                distance_m,
            )


            print(
                "[WHEEL] 🐹 Actividad finalizada."
            )


    except json.JSONDecodeError:

        print(
            "[MQTT] ❌ JSON de rueda inválido."
        )

        db.rollback()


    except Exception as error:

        db.rollback()

        print(
            "[MQTT] ❌ Error guardando rueda:"
        )

        print(
            f"        {error}"
        )


    finally:

        db.close()


# =========================================================
# ESTADO DE ALIMENTACIÓN
# =========================================================

def process_feeding_status(
    payload: str,
):

    db = SessionLocal()


    try:

        data = json.loads(
            payload
        )


        feeding_id = data.get(
            "feeding_id"
        )


        status = str(
            data.get(
                "status",
                "",
            )
        ).upper()


        print(
            "[MQTT] Estado alimentación:"
        )

        print(
            f"       ID: {feeding_id}"
        )

        print(
            f"       Estado: {status}"
        )


        # -------------------------------------------------
        # SUCCESS
        # -------------------------------------------------

        if status == "SUCCESS":

            notify_feeding_success(
                db,
                feeding_id,
            )


            print(
                "[FEEDING] ✅ Alimentación completada."
            )


        # -------------------------------------------------
        # FAILED
        # -------------------------------------------------

        elif status == "FAILED":

            notify_feeding_failed(
                db,
                feeding_id,
            )


            print(
                "[FEEDING] ❌ Alimentación fallida."
            )


        else:

            print(
                "[FEEDING] Estado no reconocido."
            )


    except json.JSONDecodeError:

        print(
            "[MQTT] ❌ Estado alimentación inválido."
        )

        db.rollback()


    except Exception as error:

        db.rollback()

        print(
            "[MQTT] ❌ Error procesando alimentación:"
        )

        print(
            f"        {error}"
        )


    finally:

        db.close()


# =========================================================
# PUBLICAR ALIMENTACIÓN
# =========================================================

def publish_feeding(
    feeding_id: int,
    duration_seconds: float,
):

    if not client.is_connected():

        print(
            "[MQTT] ❌ No conectado. "
            "No se puede publicar alimentación."
        )

        return False


    message = {
        "action": "FEED",
        "feeding_id": feeding_id,
        "duration_seconds": duration_seconds,
    }


    payload = json.dumps(
        message
    )


    result = client.publish(
        MQTT_FEED_TOPIC,
        payload,
        qos=1,
    )


    if (
        result.rc
        ==
        mqtt.MQTT_ERR_SUCCESS
    ):

        print(
            "[MQTT] ✅ Alimentación enviada:"
        )

        print(
            f"       {payload}"
        )

        return True


    print(
        "[MQTT] ❌ No se pudo publicar "
        "la alimentación."
    )

    print(
        f"       Código: {result.rc}"
    )


    return False