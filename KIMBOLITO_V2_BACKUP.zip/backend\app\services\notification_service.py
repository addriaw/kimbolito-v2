from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.orm import Session

from app.models.notification import Notification
from app.models.sensor import SensorData
from app.models.wheel_activity import WheelActivity
from app.models.feeding import FeedingRecord

from app.services.push_service import send_push_to_all


# =========================================================
# CONFIGURACIÓN
# =========================================================

# Temperatura y humedad:
# se permite una nueva alerta cada 15 segundos.
SENSOR_ALERT_COOLDOWN_SECONDS = 15

TEMP_MIN = 18.0
TEMP_MAX = 35.0

HUM_MIN = 40.0
HUM_MAX = 80.0


# =========================================================
# FUNCIONES AUXILIARES
# =========================================================

def _get_latest_sensor(db: Session) -> Optional[SensorData]:
    return (
        db.query(SensorData)
        .order_by(SensorData.fecha_registro.desc())
        .first()
    )


def _get_latest_wheel(db: Session) -> Optional[WheelActivity]:
    return (
        db.query(WheelActivity)
        .order_by(WheelActivity.created_at.desc())
        .first()
    )


def _get_latest_feeding(db: Session) -> Optional[FeedingRecord]:
    return (
        db.query(FeedingRecord)
        .order_by(FeedingRecord.created_at.desc())
        .first()
    )


def _format_datetime(value: Optional[datetime]) -> str:
    if value is None:
        return "Sin lectura"

    # Compatible con Windows: no usamos %-d ni %-I.
    months = [
        "ene",
        "feb",
        "mar",
        "abr",
        "may",
        "jun",
        "jul",
        "ago",
        "sept",
        "oct",
        "nov",
        "dic",
    ]

    month_name = months[value.month - 1]

    hour = value.hour
    suffix = "a. m." if hour < 12 else "p. m."
    hour_12 = hour % 12

    if hour_12 == 0:
        hour_12 = 12

    return (
        f"{value.day} {month_name} {value.year}, "
        f"{hour_12}:{value.minute:02d}:{value.second:02d} "
        f"{suffix}"
    )


def _get_temperature_status(temperature: float) -> str:
    if temperature < TEMP_MIN or temperature > TEMP_MAX:
        return "🔴 Alerta"

    return "🟢 Normal"


def _get_humidity_status(humidity: float) -> str:
    if humidity < HUM_MIN or humidity > HUM_MAX:
        return "🔴 Alerta"

    return "🟢 Normal"


def _get_light_status(sensor: Optional[SensorData]) -> str:
    if sensor is None:
        return "Desconocida"

    return "Encendida" if sensor.luz_encendida else "Apagada"


def _get_wheel_status(wheel: Optional[WheelActivity]) -> str:
    if wheel is None:
        return "❌ No"

    return "✅ Sí" if wheel.movement_detected else "❌ No"


def _get_feeding_status(feeding: Optional[FeedingRecord]) -> str:
    if feeding is None:
        return "Sin registro"

    status = str(feeding.status).upper()

    if status == "SUCCESS":
        return "✅ Realizada"

    if status == "FAILED":
        return "❌ Fallida"

    if status == "RUNNING":
        return "⏳ En curso"

    if status == "PENDING":
        return "⏳ Pendiente"

    return status


# =========================================================
# CONSTRUIR ALERTA GENERAL
# =========================================================

def build_monitoring_message(
    db: Session,
    action: str,
) -> str:
    sensor = _get_latest_sensor(db)
    wheel = _get_latest_wheel(db)
    feeding = _get_latest_feeding(db)

    if sensor is not None:
        temperature = f"{sensor.temperatura:.1f} °C"
        temperature_status = _get_temperature_status(
            sensor.temperatura
        )

        humidity = f"{sensor.humedad:.1f} %"
        humidity_status = _get_humidity_status(
            sensor.humedad
        )

        light_status = _get_light_status(sensor)
        last_reading = _format_datetime(
            sensor.fecha_registro
        )
    else:
        temperature = "--"
        temperature_status = "🟢 Normal"
        humidity = "--"
        humidity_status = "🟢 Normal"
        light_status = "Desconocida"
        last_reading = "Sin lectura"

    wheel_status = _get_wheel_status(wheel)
    feeding_status = _get_feeding_status(feeding)

    return (
        "🔔 Estado del monitoreo\n\n"

        "🌡️ Temperatura:\n"
        f"{temperature}\n"
        f"{temperature_status}\n\n"

        "💧 Humedad:\n"
        f"{humidity}\n"
        f"{humidity_status}\n\n"

        "💡 Luz:\n"
        f"{light_status}\n\n"

        "🐹 Rueda:\n"
        f"Ejercicio: {wheel_status}\n\n"

        "🍽️ Alimentación:\n"
        f"{feeding_status}\n\n"

        "🕐 Última lectura:\n"
        f"{last_reading}\n\n"

        "⚠️ Acción:\n"
        f"{action}"
    )


# =========================================================
# CREAR NOTIFICACIÓN
# =========================================================

def create_notification(
    db: Session,
    notification_type: str,
    title: str,
    message: str,
    severity: str = "INFO",
    cooldown_seconds: int = 0,
) -> Optional[Notification]:

    # -----------------------------------------------------
    # COOLDOWN OPCIONAL
    # -----------------------------------------------------

    if cooldown_seconds > 0:

        cutoff = (
            datetime.utcnow()
            - timedelta(seconds=cooldown_seconds)
        )

        recent_notification = (
            db.query(Notification)
            .filter(
                Notification.type == notification_type,
                Notification.created_at >= cutoff,
            )
            .order_by(
                Notification.created_at.desc()
            )
            .first()
        )

        if recent_notification:
            print(
                "[NOTIFICATION] Cooldown activo: "
                f"{notification_type}"
            )
            return None

    # -----------------------------------------------------
    # CREAR REGISTRO
    # -----------------------------------------------------

    notification = Notification(
        type=notification_type,
        title=title,
        message=message,
        severity=severity,
        is_read=False,
    )

    db.add(notification)
    db.commit()
    db.refresh(notification)

    print("")
    print("==========================================")
    print("[NOTIFICATION] Nueva notificación")
    print(f"  Tipo: {notification_type}")
    print(f"  Título: {title}")
    print(f"  Severidad: {severity}")
    print("==========================================")
    print("")

    # -----------------------------------------------------
    # AVISO DEL NAVEGADOR / CELULAR
    # -----------------------------------------------------

    try:
        send_push_to_all(
            db=db,
            title=title,
            message=message,
            notification_type=notification_type,
            severity=severity,
        )
    except Exception as error:
        print(
            "[PUSH] Error enviando notificación: "
            f"{error}"
        )

    return notification


# =========================================================
# ALIMENTACIÓN
# =========================================================

def notify_feeding_success(
    db: Session,
    feeding_id: Optional[int],
):
    if feeding_id is not None:
        action = (
            "🍽️ Alimentación completada "
            f"correctamente (#{feeding_id})."
        )
    else:
        action = "🍽️ Alimentación completada correctamente."

    return create_notification(
        db=db,
        notification_type="FEEDING_SUCCESS",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            action,
        ),
        severity="SUCCESS",
    )


def notify_feeding_failed(
    db: Session,
    feeding_id: Optional[int],
):
    if feeding_id is not None:
        action = (
            "❌ Alimentación fallida "
            f"(#{feeding_id})."
        )
    else:
        action = "❌ Alimentación fallida."

    return create_notification(
        db=db,
        notification_type="FEEDING_FAILED",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            action,
        ),
        severity="ERROR",
    )


# =========================================================
# TEMPERATURA
# =========================================================

def notify_temperature_alert(
    db: Session,
    temperature: float,
):
    return create_notification(
        db=db,
        notification_type="TEMPERATURE_ALERT",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            f"🌡️ Temperatura fuera de rango: "
            f"{temperature:.1f} °C.",
        ),
        severity="WARNING",
        cooldown_seconds=SENSOR_ALERT_COOLDOWN_SECONDS,
    )


def notify_temperature_normal(
    db: Session,
    temperature: float,
):
    return create_notification(
        db=db,
        notification_type="TEMPERATURE_NORMAL",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            f"🌡️ Temperatura normalizada: "
            f"{temperature:.1f} °C.",
        ),
        severity="SUCCESS",
    )


# =========================================================
# HUMEDAD
# =========================================================

def notify_humidity_alert(
    db: Session,
    humidity: float,
):
    return create_notification(
        db=db,
        notification_type="HUMIDITY_ALERT",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            f"💧 Humedad fuera de rango: "
            f"{humidity:.1f} %.",
        ),
        severity="WARNING",
        cooldown_seconds=SENSOR_ALERT_COOLDOWN_SECONDS,
    )


def notify_humidity_normal(
    db: Session,
    humidity: float,
):
    return create_notification(
        db=db,
        notification_type="HUMIDITY_NORMAL",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            f"💧 Humedad normalizada: "
            f"{humidity:.1f} %.",
        ),
        severity="SUCCESS",
    )


# =========================================================
# LUZ
# =========================================================

def notify_light_on(
    db: Session,
):
    return create_notification(
        db=db,
        notification_type="LIGHT_ON",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            "💡 La iluminación se encendió.",
        ),
        severity="INFO",
    )


def notify_light_off(
    db: Session,
):
    return create_notification(
        db=db,
        notification_type="LIGHT_OFF",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            "💡 La iluminación se apagó.",
        ),
        severity="INFO",
    )


# =========================================================
# RUEDA
# =========================================================

def notify_wheel_started(
    db: Session,
):
    return create_notification(
        db=db,
        notification_type="WHEEL_STARTED",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            "🐹 Ejercicio detectado: "
            "el hámster comenzó a utilizar la rueda.",
        ),
        severity="INFO",
    )


def notify_wheel_finished(
    db: Session,
    revolutions: Optional[int] = None,
    distance_m: Optional[float] = None,
):
    return create_notification(
        db=db,
        notification_type="WHEEL_FINISHED",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            "🐹 El hámster terminó su ejercicio "
            "en la rueda.",
        ),
        severity="SUCCESS",
    )


# =========================================================
# ESP32
# =========================================================

def notify_esp32_online(
    db: Session,
):
    return create_notification(
        db=db,
        notification_type="ESP32_ONLINE",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            "📡 ESP32 conectado y comunicándose "
            "correctamente.",
        ),
        severity="SUCCESS",
    )


def notify_esp32_offline(
    db: Session,
):
    return create_notification(
        db=db,
        notification_type="ESP32_OFFLINE",
        title="🐹 KIMBOLITO",
        message=build_monitoring_message(
            db,
            "📡 ESP32 sin comunicación con el sistema.",
        ),
        severity="ERROR",
    )
