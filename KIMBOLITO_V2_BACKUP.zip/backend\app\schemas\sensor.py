from datetime import datetime

from pydantic import BaseModel, Field


class SensorCreate(BaseModel):

    temperatura: float

    humedad: float

    luz_encendida: bool = False


class SensorResponse(BaseModel):

    id: int

    temperatura: float

    humedad: float

    luz_encendida: bool

    fecha_registro: datetime

    model_config = {
        "from_attributes": True
    }